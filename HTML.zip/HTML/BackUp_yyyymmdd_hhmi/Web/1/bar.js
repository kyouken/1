
jQuery(function($) {
$('#r4').tablesorter({
  widgets: ['zebra'],
  sortList: [[0, 1]],
});

});


