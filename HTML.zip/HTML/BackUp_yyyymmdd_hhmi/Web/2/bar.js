
$(document).ready(function ($) {

    $('#tabs').tabulous();  

});

