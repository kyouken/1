

$(document).ready(function(){

    $("#animate").click(function(){
      $(".block").animate(
        {width: "toggle", opacity: "toggle"},
        "slow", "easeInQuart"
      );
    });

});

