$(function(){
	$("#menu li").hover(function(){
		$("ul",this).show();
	},
	function(){
		$("ul",this).hide();
	});
});


$(function(){
	$(".submenu li").hover(function(){
		$("ul",this).show();
	},
	function(){
		$("ul",this).hide();
	});
});


