//2011年用welcomeカレンダーファイル（bizad）が読み込まれていれば実行。
if (typeof(welcomeSchedule) != 'undefined'){

 //welcome、top welcomeの飛び先を定義
 welcomeSchedule.welcomUrl = 'http://itpro.nikkeibp.co.jp/welcome/welcomeart.html';
 welcomeSchedule.topWelcomUrl = 'http://itpro.nikkeibp.co.jp/welcome/welcome.html';

 welcomeSchedule.init = function(){
  var c, cname, topFlag, cterm;
  if (!((location.protocol.toLowerCase().indexOf('http') == 0) && location.host.match(/itpro\.nikkeibp\.co\.jp$/i))) return;
  if (welcomeSchedule.getopt(location.href, 'rt') == 'nocnt') return;

  cterm = (Math.floor((new Date()).getTime() / 1000) + 60 * 60 * 12).toString();
  topFlag = ((location.pathname == '/') || (location.pathname == '/index.html'));
  if ((topFlag && welcomeSchedule.isViewDate(welcomeSchedule.twbs, welcomeSchedule.twbe)) || ((!topFlag) &&  welcomeSchedule.isViewDate(welcomeSchedule.wbs, welcomeSchedule.wbe))){
   c = welcomeSchedule.eatCookie('wabwb2011');
   if (c){
    if ((c * 1000 < (new Date()).getTime())){
     welcomeSchedule.bakeDomainCookie('wabwb2011', cterm, false);
     welcomeSchedule.goWelcomeSite(topFlag ? welcomeSchedule.topWelcomUrl : welcomeSchedule.welcomUrl);
    }
   }else{
    welcomeSchedule.bakeDomainCookie('wabwb2011', cterm, false);
    welcomeSchedule.goWelcomeSite(topFlag ? welcomeSchedule.topWelcomUrl : welcomeSchedule.welcomUrl);
   }
  }
 }

 welcomeSchedule.eatCookie = function(key){
  var dc, cs, i, p;
  dc = document.cookie;
  cs = dc.split(/; ?/);
  for(i=0; i<cs.length; i++){
   p = cs[i].indexOf(key + '=');
   if (p == 0){
    return(cs[i].substr(key.length + 1));
   }
  }
  return('');
 }

 welcomeSchedule.bakeDomainCookie = function(name, value, isDomain){
  var expire, t, d;
  d = isDomain ? 'nikkeibp.co.jp' : location.hostname;
  expire = new Date();
  expire.setTime(expire.getTime() + (60 * 60 * 12 * 1000));
  document.cookie =  name + "=" + encodeURIComponent(value) + '; domain=' + d + '; path=/; expires=' + expire.toGMTString();
 },

 welcomeSchedule.getopt = function(s, name){
  var i;
  if (s.indexOf('#') >= 0)
   s = s.substring(0, s.indexOf('#'));
  if (s = s.split('?')[1]){
   var opts = new Array();
   opts = s.split('&');
   for(i = 0; i < opts.length; i++){
    if (opts[i].substring(0, name.length + 1).toLowerCase() == (name.toLowerCase() + '=')){
     return(opts[i].substring(name.length + 1));
    }
   }
  }
  return('');
 }
 welcomeSchedule.isViewDate = function(st, ed){
  var n;
  n = (new Date()).getTime();
  return(((new Date(st[0], st[1] -1, st[2])).getTime() <= n) && ((new Date(ed[0], ed[1] -1, ed[2])).getTime() >= n));
 }

 welcomeSchedule.goWelcomeSite = function(url){
  location.href = url + '?' + encodeURIComponent(location.href);
 }

 welcomeSchedule.init();

}