document.write('<script type="text/javascript" charset="utf-8" src="http://bizad.nikkeibp.co.jp/NBP_AD/itpro/parts/itp_welcome_schedule.js?' + (new Date()).getTime().toString() + '"></script>');
