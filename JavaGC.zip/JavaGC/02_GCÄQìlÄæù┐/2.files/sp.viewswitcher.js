/************************************************
 * View switcher for smartphone.  
 * Last Modified : $Date: 2011/01/11 10:19:00 $
 * Version       : $Revision: 1.4 $
 ************************************************/
 
/*TOC===============================================
Set view mode
Read and Write Cookie
Reload the page
==================================================*/

/*Set view mode
--------------------------------------------*/
/*
arguments
name: "sp_[serviceName]_view_type";
value: "pc" or ""; ("" = smart phone)
days: 1095;
domain: "ameba.jp";
path: "/";
*/

/* Set pc view: for smartphone */
function setPcView(name, domain, path){
	var value = "pc";
	var days = "1095";
	res = confirm("パソコン版へ切り替えますか？\n\nページ下のリンクから再度モバイル版に戻すこともできます。");
	if (res == true) {
			writeCookie(name, value, days, domain, path);
			location.reload();
	} else {
		return false;
	}
}

/* Set sp view: for pc */
function setSpView(name, domain, path){
	var value = "";
	var days = "-1";
	writeCookie(name, value, days, domain, path);
	location.reload();
}


/*OLD*/
function setViewMode(name, value, days, domain, path){
	if (value) {
		res = confirm("パソコン版へ切り替えますか？\n\nページ下のリンクから再度モバイル版に戻すこともできます。");
		if (res == true) {
			writeCookie(name, value, days, domain, path);
			location.reload();
		} else {
			return false;
		}
	} else {
		writeCookie(name, value, days, domain, path);
		location.reload();
	}
}

/*Read and Write Cookie
--------------------------------------------*/
/*Read a cookie*/
function readCookie(name){
	var searchName = name + "="; //さがすcookie nameを指定
	var cookies = document.cookie.split(';'); //;で区切って name=valueの形に
	for(var i=0; i < cookies.length; i++){ //cookiesの数分さがす
		var cookie = cookies[i]; //前から1つずつcookieに代入
		while(cookie.charAt(0) == ' '){ //新しいcookieだったらcookie nameを抜き出し
			cookie = cookie.substring(1, cookie.length);
		}
			
		if(cookie.indexOf(searchName) == 0){ //さがすnameと一致したらvalueを抜き出し返す
			return cookie.substring(searchName.length, cookie.length)
		}
	}
	return ""; // 見つからない時は空文字を返す
}

/*Write a cookie*/
function writeCookie(name, value, days, domain, path){
     var cookie = name + "=" + escape(value) + ";";//nameとvalueを代入
          if (days != 0) { //有効期限設定 0日の時以外
          var date = new Date(); //現在の日時を取得
          date.setDate(date.getDate() + days); //日後の設定
          cookie += "expires=" + date.toGMTString() + ";"; //expiresを追加指定
     }
	 cookie += "domain=" + domain + ";" + "path=" + path +";"; //domain, pathを追加指定
     document.cookie = cookie; //Cookieに書き出し
}

/*Reload the page
--------------------------------------------*/
function reloadPage(){
	location.reload();
}