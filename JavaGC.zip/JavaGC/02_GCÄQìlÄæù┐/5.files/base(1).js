/*
titleCutList.compareExcludeURL = function(urldata){
	var list = [
		"/ait/articles/1304/11/news020.html"
	];
	for(var i=0; i<list.length; i++){
		if(urldata.match(list[i])) return true;
	}
	return false
};
*/

// Reborn
// ========================================================
/* @IT �t�H�[�����f�[�^
------------------------------------------*/
function setForum(){
	return {
		'kw-smartandsocial':'Smart & Social',
		'kw-designhack':'�f�U�C���n�b�N',
		'kw-html5plusux':'HTML5�{UX',
		'kw-serverandstorage':'Server & Storage',
		'kw-windowsserverinsider':'Windows Server Insider',
		'kw-businessappinsider':'�Ɩ��A�v��Insider',
		'kw-insiderdotnet':'Insider.NET',
		'kw-systeminsider':'System Insider',
		'kw-railshub':'Rails Hub',
		'kw-codingedge':'Coding Edge',
		'kw-javaagile':'Java Agile',
		'kw-databaseexpert':'Database Expert',
		'kw-linuxandoss':'Linux �� OSS',
		'kw-masterofipnetwork':'Master of IP Network',
		'kw-securityandtrust':'Security & Trust',
		'kw-systemdesign':'System Design',
		'kw-testandtools':'Test & Tools',
		'kw-ljibun':'�����헪������',
		'kw-lcareer':'�L�����A����������',
		'kw-lskill':'�X�L���n��������',
		'kw-jibun':'�����헪������'
	};
}
function getForum(key){
	if(key == false || !key) return false;
	var a = setForum();
	var b = [];
	for(var i in a){
		if(key.match(i)){
			if(i=='kw-smartandsocial'){
				var path = '/ait/subtop/smart/';
				var forumid = 'smart';
			}else if(i=='kw-designhack'){
				var path = '/ait/subtop/ux/design/';
				var forumid = 'design';
			}else if(i=='kw-html5plusux'){
				var path = '/ait/subtop/ux/';
				var forumid = 'ux';
			}else if(i=='kw-serverandstorage'){
				var path = '/ait/subtop/server/';
				var forumid = 'server';
			}else if(i=='kw-windowsserverinsider'){
				var path = '/ait/subtop/win/';
				var forumid = 'win';
			}else if(i=='kw-businessappinsider'){
				var path = '/ait/subtop/dotnet/app/';
				var forumid = 'app';
			}else if(i=='kw-insiderdotnet'){
				var path = '/ait/subtop/dotnet/';
				var forumid = 'dotnet';
			}else if(i=='kw-systeminsider'){
				var path = '/ait/subtop/sys/';
				var forumid = 'sys';
			}else if(i=='kw-railshub'){
				var path = '/ait/subtop/coding/rails/';
				var forumid = 'rails';
			}else if(i=='kw-codingedge'){
				var path = '/ait/subtop/coding/';
				var forumid = 'coding';
			}else if(i=='kw-javaagile'){
				var path = '/ait/subtop/java/';
				var forumid = 'java';
			}else if(i=='kw-databaseexpert'){
				var path = '/ait/subtop/db/';
				var forumid = 'db';
			}else if(i=='kw-linuxandoss'){
				var path = '/ait/subtop/linux/';
				var forumid = 'linux';
			}else if(i=='kw-masterofipnetwork'){
				var path = '/ait/subtop/network/';
				var forumid = 'network';
			}else if(i=='kw-securityandtrust'){
				var path = '/ait/subtop/security/';
				var forumid = 'security';
			}else if(i=='kw-systemdesign'){
				var path = '/ait/subtop/systemdesign/';
				var forumid = 'systemdesign';
			}else if(i=='kw-testandtools'){
				var path = '/ait/subtop/testtools/';
				var forumid = 'testtools';
			}else if(i=='kw-ljibun'){
				var path = '/ait/subtop/jibun/ljibun/';
				var forumid = 'ljibun';
			}else if(i=='kw-lcareer'){
				var path = '/ait/subtop/jibun/lcareer/';
				var forumid = 'lcareer';
			}else if(i=='kw-lskill'){
				var path = '/ait/subtop/jibun/lskill/';
				var forumid = 'lskill';
			}else if(i=='kw-jibun'){
				var path = '/ait/subtop/jibun/';
				var forumid = 'jibun';
			}else{
				return false;
			}
		b.push({'extraid':i,'path':path,'forumid':forumid,'name':a[i]});
		}
	}
	if(b.length == 0) return false;
	return b;
}

// �L�����X�g�A�C���f�b�N�X��Ԃ�
function outputColIndexParts(json){
	if(!json) return false;
	var html = outputColIndexParts[json.type](json.data,json.num,json.cutnum);
	for(var i=0; i<json.id.length; i++){
		if(document.getElementById(json.id[i])) document.getElementById(json.id[i]).innerHTML = html;
	}
	return true;
};
// ���X�g�`��
outputColIndexParts.list = function(data,num,cutnum){
	for(var i=0, html="", len=data.length; i<num && i<len; i++){
		var title = cutnum ? cutString(data[i].title,40) : data[i].title;
		html += '<li class="num' + (i+1) + '"><a href="' + data[i].link + '" title="' + data[i].title + '">' + title + '</a></li>';
	}
	return html;
};
// colBox�`��
outputColIndexParts.defaultBox = function(){};

// �C�x���g�J�����_�[�p
function eventCal(json){
	if(!json) return false;
	var html = ""
	for(var i=0, html="", len=json.data.length; i<5 && i<len; i++){
		var title = cutString(json.data[i].title,40);
		html += '<li class="rank' + (i+1) + '"><a href="' + json.data[i].link + '" title="' + json.data[i].title + '">' + title + '</a></li>';
	}
	// �E�J�����p
	if(document.getElementById("js-rcolCalendarIndex")) document.getElementById("js-rcolCalendarIndex").innerHTML = html;
	// TOP�p���C���J�����p
	if(document.body.id.match("masterType-top") && document.getElementById("js-topCalendarIndex")) document.getElementById("js-topCalendarIndex").innerHTML = html;
};

// �^�u�؂�ւ�
function setTabAction(id){
	if(!id || !document.getElementById(id)) return false;
	var tgt = document.getElementById(id);
	var tab = tgt.getElementsByTagName('h2');
	for(var i=0,len=tab.length; i<len; i++){
		tab[i].onclick = setTabAction.changeTab;
	}
};

setTabAction.changeTab = function(){
	var self = jQuery(this);
	self.parent().children("h2").removeClass("active");
	self.addClass("active");
	var tgt = self.parent().parent().children("div.colBoxInner").children("div.colBoxIndex");
	tgt.removeClass('active');
	jQuery(tgt[self.index()]).addClass('active');
};

// �t�H�[�����ʂ̃��S���o��
function outputForumLogo(){
	var metadata = getForum(getMETA('extraid').content),
		tgt = jQuery("#colBoxSubChannelLogo"),
		aTag = jQuery(document.createElement("a"));
	if(metadata == false) return false;
	for(var i = 0; i < metadata.length; i++){
		aTag.attr("href", metadata[i]['path']).attr("title", metadata[i]['name']).html(metadata[i]['name']).css("background-image","url(" + imgSrv() + "/ait/images/title_forum_small_" + metadata[i]['forumid'] + ".gif)");
		tgt.append(aTag);
		if(metadata[i]['path'].match('/ait/subtop/dotnet/app/')){
			var divTag = jQuery(document.createElement("div")).addClass("colBoxSubChannelSponsor").html("<h2>Supported by �O���[�v�V�e�B</h2>");
			tgt.append(divTag);
		}
		break;
	}
	return true;
};

function setTabActionStrong(id){
	if(!id || !document.getElementById(id)) return false;
	var tgt = document.getElementById(id);
	var tab = tgt.getElementsByTagName('strong');
	for(var i=0,len=tab.length; i<len; i++){
		tab[i].onclick = setTabActionStrong.changeTab;
	}
};
setTabActionStrong.changeTab = function(){
	var self = jQuery(this);
	self.parent().children("strong").removeClass("active");
	self.addClass("active");
	var tgt = self.parent().parent().children("div.colBoxInner").children("div.colBoxIndex");
	tgt.removeClass('active');
	jQuery(tgt[self.index()]).addClass('active');
};

// �t�H�[�����L�������L���O�p��json�𕪊�
function setForumRankingMonthAndDay(){
	if (!document.getElementById('colBoxArticleRanking')) { return false; }
	var forumName ='';
	var forum = '';
	if(masterType() == 'article') {
		var fdata = getForum(getMETA('extraid').content)[0];
		if(!fdata) return false;
		forum = fdata.forumid;
		forumName = fdata.name;
		if (forumName.match('�Ɩ��A�v��Insider')){
			forumName = 'Insider.NET';
		}
	} else if(masterType() == 'subtop'){
		var a = getUrl()['path'];
		if(a.match('/ait/subtop/smart/')){
			forum = 'smart';
			forumName ='Smart & Social';
		}else if(a.match('/ait/subtop/ux/design/')){
			forum = 'design';
			forumName ='�f�U�C���n�b�N';
		}else if(a.match('/ait/subtop/ux/')){
			forum = 'ux';
			forumName ='HTML5�{UX';
		}else if(a.match('/ait/subtop/server/')){
			forum = 'server';
			forumName ='Server & Storage';
		}else if(a.match('/ait/subtop/win/')){
			forum ='win';
			forumName ='Windows Server Insider';
		}else if(a.match('/ait/subtop/dotnet/app/')){
			forum = 'app';
			forumName ='�Ɩ��A�v��Insider';
		}else if(a.match('/ait/subtop/dotnet/')){
			forum = 'dotnet';
			forumName ='Insider.NET';
		}else if(a.match('/ait/subtop/sys/')){
			forum = 'sys';
			forumName ='System Insider';
		}else if(a.match('/ait/subtop/coding/rails/')){
			forum = 'rails';
			forumName ='Rails Hub';
		}else if(a.match('/ait/subtop/coding/')){
			forum = 'coding';
			forumName ='Coding Edge';
		}else if(a.match('/ait/subtop/java/')){
			forum = 'java';
			forumName ='Java Agile';
		}else if(a.match('/ait/subtop/db/')){
			forum = 'db';
			forumName ='Database Expert';
		}else if(a.match('/ait/subtop/linux/')){
			forum = 'linux';
			forumName ='Linux �� OSS';
		}else if(a.match('/ait/subtop/network/')){
			forum = 'network';
			forumName ='Master of IP Network';
		}else if(a.match('/ait/subtop/security/')){
			forum = 'security';
			forumName ='Security & Trust';
		}else if(a.match('/ait/subtop/features/kwd/security_glossary.html')){
			forum = 'security';
			forumName ='Security & Trust';
		}else if(a.match('/ait/subtop/systemdesign/')){
			forum = 'systemdesign';
			forumName ='System Design';
		}else if(a.match('/ait/subtop/testtools/')){
			forum = 'testtools';
			forumName ='Test & Tools';
		}else if(a.match('/ait/subtop/jibun/ljibun/')){
			forum = 'ljibun';
			forumName ='�����헪������';
		}else if(a.match('/ait/subtop/jibun/lcareer/')){
			forum = 'lcareer';
			forumName ='�L�����A����������';
		}else if(a.match('/ait/subtop/jibun/lskill/')){
			forum = 'lskill';
			forumName ='�X�L���n��������';
		}else if(a.match('/ait/subtop/jibun/')){
			forum = 'jibun';
			forumName ='�����헪������';
		} else {
			forum = 'top';
			forumName ='����';
		}
	} else {
		forum = 'top';
		forumName ='����';
	}
	if(forum){
		var forumNameText = '';
		if(masterType() == 'top'){ 
			forumNameText = forumName;
		} else {
			forumNameText = forumName + '&nbsp;';
		}
		var rankingTag = '<div class="colBoxOuter"><div class="colBoxHead"><h2>'+ forumNameText +'�L�������L���O</h2></div><div class="colBoxClear"></div><div class="colBoxRankTab"><strong class="tab1 active"><span>�{��</span></strong><strong class="tab2"><span>����</span></strong></div><div class="colBoxInner"><div class="colBoxIndex colBoxIndexTab1 active" id="colBoxIndexTab1"></div><div class="colBoxIndex colBoxIndexTab2" id="colBoxIndexTab2"></div></div></div></div>'
		document.getElementById('colBoxArticleRanking').innerHTML = rankingTag;
		var scriptAdd = document.getElementById('colBoxArticleRanking');

		if (forum == 'security') {forum = 'securitytrust'};
		if (forum == 'win') {forum = 'windows'};

		var scriptElementUrl = '/json/ait/rss_reborn_' + forum + '_ranking_day.json';
		var scriptElementUrl2 = '/json/ait/rss_reborn_' + forum + '_ranking_month.json';
		var scriptElement1 = document.createElement('script');
		var scriptElement2 = document.createElement('script');
		scriptElement1.type = 'text/javascript';
		scriptElement2.type = 'text/javascript';
		scriptElement1.src = scriptElementUrl;
		scriptElement2.src = scriptElementUrl2;
		eval('scriptAdd.appendChild(scriptElement1);');
		eval('scriptAdd.appendChild(scriptElement2);');
	}
	setTabActionStrong('colBoxArticleRanking');
	return true;
};

// �t�H�[�����L�������L���O�o��
function outputForumRankingMonthAndDay(json){
	if(!json) return false;
	var data = json.data;
	var html = "";
	for(var i=0,len=data.length; i<len; i++){
		if(!data[i].link) continue;
		html += '<li class="rank' + (i+1) + '"><a href="' + data[i].link + '" title="' + data[i].title + '">' + data[i].title + '</a></li>';
	}
	var forumRankingTag = '<div class="colBoxUlist"><ul>'+ html +'</ul></div>';
	var RankingTagNum ='';
	if(json.tabNum == "Tab1"){ 
		RankingTagNum = "colBoxIndexTab1";
	} else {
		RankingTagNum = "colBoxIndexTab2";
	}
	document.getElementById(RankingTagNum).innerHTML = forumRankingTag;
	return true;
};

// �t�H�[�����L�������L���O�o�̓A�C�R���t
function outputForumRankingWithicon(json){
	if(!json) return false;
	var data = json.data;
	var html = '';
	var rankcount = '';
	for(var i=0,len=data.length; i<len; i++){
		if(!data[i].link) continue;
		if(i > 4) {rankcount = 'rankover'};
		html += '<div class="colBoxRank rank' + (i+1) + ' ' + rankcount + '">';
		html += '<div class="colBoxRankIcon"><a href="' + data[i].link + '" title="' + data[i].title + '"><img src="' + imgSrv() + data[i].image +'"></a></div>';
		html += '<div class="colBoxRankTitle"><h3><a href="' + data[i].link + '" title="' + data[i].title + '">' + data[i].title + '</a></h3></div>';
		html += '<div class="colBoxRankNum"><span>' + (i+1) + '</span></div>';
		html += '</div><div class="colBoxClear"></div>';
	}
	var forumRankingTag = html;
	var RankingTagNum ='';
	if(json.tabNum == "Tab1"){ 
		RankingTagNum = "colBoxIndexTab1";
	} else {
		RankingTagNum = "colBoxIndexTab2";
	}
	document.getElementById(RankingTagNum).innerHTML = forumRankingTag;
	return true;
};

// �g���� HTML�G�X�P�[�v�΍�
function outputTrain(json){
	if(!json) return false;
	var data = json.data,
		html = "";
	
	for(var i=0; i<data.length; i++){
		if(!data[i].link) continue;
		html += '<div class="colBoxTitle"><h3><a href="' + data[i].link + '" title="' + data[i].category + '">' + data[i].category + '</a></h3></div>'
				+ '<div class="colBoxDescription"><p>' + data[i].description.replace(/</g,'&lt').replace(/>/g,'&gt') + '<span class="colBoxDate">�i' + data[i].yyyy + '/' + data[i].mm + '/' + data[i].dd + '�j</span></p></div>'
				+ '<div class="colBoxAnsBtn"><a href="' + data[i].link + '" title="���ɒ��킷��">���ɒ��킷��</a></div>'
				+ '<div class="colBoxClear"></div>';
	};
	document.getElementById('colBoxITTRAIN').innerHTML = html;
	return true;
};

// �}�[�W�����L���O
function margeArtRanking(json){
	// �f�[�^������ꍇ�ɂ͔z��ɒǉ�
	if(json) return margeArtRanking.setAry(json.data);
	if(margeArtRanking.artObj.length == 0) return false;
	
	// �L������t���Ƀ\�[�g
	margeArtRanking.sortAry();
	
	// �����L���O���o��
	margeArtRanking.output();
};
margeArtRanking.artObj = [];
margeArtRanking.setAry = function(data){
	for(var i=0; i<data.length; i++){
		if(data[i].link) margeArtRanking.artObj.push(data[i]);
	}
	return true;
};
margeArtRanking.sortAry = function(){
	margeArtRanking.artObj.sort(
		function(a,b){
			return a.date > b.date ? -1 : 1;
		}
	);
};
margeArtRanking.output = function(){
	var html = "",
		count = 0;
	for(var i=0,len=margeArtRanking.artObj.length; i<len && count<10; i++){
		if(!margeArtRanking.artObj[i].link) continue;
		// �^�C�v�ʕ���
		if(margeArtRanking.artObj[i].subject == 'matome') {
			var typename="type-matome";
		} else if(margeArtRanking.artObj[i].subject == 'event') {
			var typename="type-event";
		} else if(margeArtRanking.artObj[i].subject == 'news') {
			var typename="type-news";
		}
		html += '<li class="' + typename + '"><a href="' + margeArtRanking.artObj[i].link + '" title="' + margeArtRanking.artObj[i].title + '"  onclick="designCnt(\'margeRanking\',\'' + typename + '\');">' + margeArtRanking.artObj[i].title + '</a></li>';
		count++;
	}
	document.getElementById("margeRanking").innerHTML = '<div class="colBoxOuter">'
	+ '<div class="colBoxHead"><h2>News/�܂Ƃ߁�IT/�C�x���g���O</h2></div>'
	+ '<div class="colBoxInner"><div class="colBoxIndex"><div class="colBoxUlist"><ul>'
	+ html
	+ '</ul></div></div></div>'
	+ '</div>';
	return true;
};


/* Ait�\�[�V�����p�[�c 
-----------------------------------------------------------------------*/
function aitSnsContents(data){
	aitSnsContents.writ(aitSnsContents.code(data));
	aitSnsContents.getTarget();
	aitSnsContents.getContents();
	aitSnsContents.setButtons();
	aitSnsContents.addButtons();
	aitSnsContents.setFirstEvent();
};
aitSnsContents.code = function(data){
	if(!data['boxid']) data['boxid'] = '';
	if(!data['width']) data['width'] = '300px';
	var code = {
	'colBoxSnsMostpopular':(function(){
		if(!data['likebox'] || data['likebox'] == ''){
			return '';
		}else{
		var streamparams = ''; 
		var heightparams = ''; 
			if(data['activitydomain'] == 'http://www.atmarkit.co.jp/ait/subtop/jibun/'){
				streamparams  = true;
				heightparams = 580;
			} else {
				streamparams  = false;
				heightparams = 280;
			}
		var likeboxparams = '' +
		'href=http%3A%2F%2Fwww.facebook.com%2F' + data['likebox'] + '&amp;' +
		'width=' + data['width'].replace('px','') + '&amp;' +
		'height=' + heightparams + '&amp;' +
		'colorscheme=light&amp;' +
		'show_faces=true&amp;' +
		'header=true&amp;' +
		'stream=' + streamparams + '&amp;' +
		'show_border=true'
		return '' +
		'<div class="colBox colBoxSnsMostpopular" id="colBoxSnsMostpopular' + data['boxid'] + '">' +
		'<div class="colBoxOuter">' +
		'<div class="colBoxHead"><h2 name="Facebook">Facebook</h2></div>' +
		'<div class="colBoxInner">' +
		'<iframe src="//www.facebook.com/plugins/likebox.php?' +
		likeboxparams + 
		'" scrolling="no" frameborder="0" style="border:none;overflow:hidden;width:' + data['width'] + ';height:' + heightparams + 'px;" allowTransparency="true"></iframe>' +
		'</div>' +
		'</div>' +
		'</div>'
		}
	})(),
	'colBoxSnsEmbeddedTimelines':(function(){
		if(!data['tw_widget_id'] || data['tw_widget_id'] == '' || !data['twitterid'] || data['twitterid'] == ''){
			return '';
		}else{
			return '' + 
			'<div class="colBox colBoxSnsEmbeddedTimelines" id="colBoxSnsEmbeddedTimelines' + data['boxid'] + '"><div class="colBoxOuter">' +
			'<div class="colBoxHead"><h2 name="Twitter">Twitter</h2></div>' +
			'<div class="colBoxInner">' +
			'<a class="twitter-timeline" href="https://twitter.com/' + data['twitterid'] + '" data-widget-id="' + data['tw_widget_id'] + '" width="' + data['width'] + '" height="350">@' + data['twitterid'] + ' ����̃c�C�[�g</a>' + 
			'<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");<\/script>' +
			'</div>' +
			'</div></div>';
		}
	})()

	};
	return {'code':code,'boxid':data['boxid'],'width':data['width']};
};
aitSnsContents.writ = function(data){
	this.boxid = data['boxid'];
	document.write('<div class="snsContents" id="snsContents' + this.boxid + '" style="width:' + data['width'] + ';">');
	for(var i in data['code']){
		document.write(data['code'][i]);
	}
	document.write('</div>');
};

aitSnsContents.getTarget = function(){
	this.target = document.getElementById('snsContents' + this.boxid);
};
aitSnsContents.getContents = function(){
	var a = this.target.getElementsByTagName('div');
	this.contents = [];
	for(var i = 0; i < a.length; i++){
		if(a[i].className.match(/^colBox /)){
			if(!a[i].getElementsByTagName('h2')[0]) continue;
			var b = a[i].getElementsByTagName('h2')[0];
			this.contents.push({'name':b.innerHTML,'forumid':b.getAttribute('name'),'content':a[i]});
 		}
	}
};
aitSnsContents.setButtons = function(){
	this.buttonsCode = [];
	for(var i = 0; i < this.contents.length; i++){
		this.buttonsCode.push('<li name="' + this.contents[i]['forumid'] + '" onClick="aitSnsContents.setEventClick(' + i + ',this);" onMouseOver="aitSnsContents.setEventHover(\'hover\',this);" onMouseOut="aitSnsContents.setEventHover(\'out\',this);">' + this.contents[i]['name'] + '</li>');
	}
};
aitSnsContents.addButtons = function(){
	var a = [];
	a.push('<div class="colBox">');
	a.push('<div class="colBoxOuter">');
	a.push('<div class="colBoxInner">');
	a.push('<div class="colBoxIndex">');
	a.push('<div class="colBoxUlist"><ul>');
	a.push(this.buttonsCode.join(''));
	a.push('</ul></div>');
	a.push('<div class="colBoxClear"></div>');
	a.push('</div>');
	a.push('</div>');
	a.push('</div>');
	a.push('</div>');
	var b = document.createElement('div');
	b.setAttribute('id','snsButtons' + this.boxid);
	b.className = 'snsButtons';
	b.innerHTML = a.join('');
	this.target.insertBefore(b,this.target.childNodes[0]);
};
aitSnsContents.setFirstEvent = function(){
	var a = document.getElementById('snsButtons' + this.boxid);
	var buttons = a.getElementsByTagName('li');
	for(var i = 0; i < buttons.length; i++){
		if(getUrl()['url'].match('#' + buttons[i].getAttribute('name'))){
			buttons[i].className = 'active';
			aitSnsContents.setEventClick(i,buttons[i]);
			return true;
		}
	}
	buttons[0].className = 'active';
	aitSnsContents.setEventClick(0,buttons[0]);
};
aitSnsContents.setEventClick = function(number,elem){
	// BUTTONS //
	var a = elem.parentNode;
	var buttons = a.getElementsByTagName('li');
	for(var i = 0; i < buttons.length; i++){
		if(i == number){
			buttons[i].className = 'active';
		}else{
			buttons[i].className = '';
		}
	}
	// BUTTONS //
	// CONTENTSS //
	var b = a.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode;
	var c = b.childNodes;
	for(var i = 1; i < c.length; i++){
		// platform.twitter.com/widgets.js �̎��s�^�C�~���O�̊֌W��
		// display:none,block �ł͂���
		// ������ display:none ���� iframe �����������������s���Ȃ��u���E�U�iFirefox �Ŋm�F�j������
		// display ����ɕύX���E�B�W�F�b�g�������擾���邽�ߒx�����������܂���
		if((number + 1) == c.length){
			c[i].style.display = 'block';
			c[i].style.position = '';
			continue;
		}
		if(i == (number + 1)){
			c[i].style.display = 'block';
			c[i].style.position = '';
			continue;
		}
		c[i].style.display = 'none';
		c[i].style.position = 'absolute';
	}
	// CONTENTSS //
};
aitSnsContents.setEventHover = function(type,elem){
	if(elem.className == 'active') return false;
	if(type == 'hover') elem.className = 'hover';
	if(type == 'out') elem.className = '';
};


// base.js��snsContents�֐��̃��b�p�[
function snsTrigger(boxwidth){
	var type = masterType();
	if(!type) return false;
	
	if(type == "top") {
		var a = getForum(getMETA('extraid').content).path;
	} else if(type == "article") {
		var a = getForum(getMETA('extraid').content)[0].path;
	} else if(type == "subtop"){
		var a = getUrl()['path'];
	}
	
	// �eSNS�̃I�v�V�������擾
	var params = getSnsOption(a);
	
	aitSnsContents({
		width:boxwidth+"px",
		likebox: params.likebox,
		activitydomain: params.activitydomain,
		activityfilter: params.activityfilter,
		twitterid: params.twitterid,
		tw_widget_id: params.tw_widget_id
	});
	
	return true;
};

// SNS�̃t�H�[�������Ƃ́ASNS�I�v�V������Ԃ�
function getSnsOption(a){
	var params = {};
	if(!a) {
		params.likebox = 'atmarkit';
		params.activitydomain = 'http://www.atmarkit.co.jp/';
		params.activityfilter = '';
		params.twitterid = 'atmark_it';
		params.tw_widget_id = '306296222484926464';
	} else if(a.match('/ait/subtop/jibun/')) {
		params.likebox = 'atmkitjibun';
		params.activitydomain = 'http://www.atmarkit.co.jp/ait/subtop/jibun/';
		params.activityfilter = '';
		params.twitterid = 'atmkit_jibun';
		params.tw_widget_id = '567640587696754688';
	} else if(a.match('/jibun/lskill/')) {
		params.likebox = 'atmkitjibun';
		params.activitydomain = 'http://www.atmarkit.co.jp/ait/subtop/jibun/';
		params.activityfilter = '';
		params.twitterid = 'atmkit_jibun';
		params.tw_widget_id = '567640587696754688';
	} else if(a.match('/jibun/lcareer/')) {
		params.likebox = 'atmkitjibun';
		params.activitydomain = 'http://www.atmarkit.co.jp/ait/subtop/jibun/';
		params.activityfilter = '';
		params.twitterid = 'atmkit_jibun';
		params.tw_widget_id = '567640587696754688';
	} else if(a.match('/jibun/ljibun/')) {
		params.likebox = 'atmkitjibun';
		params.activitydomain = 'http://www.atmarkit.co.jp/ait/subtop/jibun/';
		params.activityfilter = '';
		params.twitterid = 'atmkit_jibun';
		params.tw_widget_id = '567640587696754688';
	} else {
		params.likebox = 'atmarkit';
		params.activitydomain = 'http://www.atmarkit.co.jp/';
		params.activityfilter = '';
		params.twitterid = 'atmark_it';
		params.tw_widget_id = '306296222484926464';
	}
	return params;
};

function designCnt(pos,opt) {
	if(designCnt.exc_list[pos] != true) return false;

	if(!opt) var opt = '';
	var channel = (function(){
		if(typeof masterChannel == 'function') return masterChannel();
		return location.pathname.split('/')[0];
	})();
	var type = (function(){
		if(typeof masterType == 'function') return masterType();
		return 'notMasterType';
	})();
	var a = channel + '_' + type + '_' + pos + ' ' + opt;
	s.prop14 = a;
	s.tl(this,'e',a);
	s_objectid = a;

};

designCnt.exc_list = {
	'alertBtnTest201312':true /* �A�ڃA���[�g */
};



