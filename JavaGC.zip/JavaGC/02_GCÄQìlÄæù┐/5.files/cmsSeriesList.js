/*
	�I�v�V����
*/
cmsSeriesList.first_pattern = 1; // �����\����ԁi0 = �ŐV���� 5 �� , 1 = ���Ă���A�ڂ���㉺ 2 ���j
cmsSeriesList.makeIndex_pattern = 0;
/*
	0 = �A�C�R�� + �^�C�g�� + �A�u�X�g���N�g + ���Җ� + �X�V����
	1 = �ԍ� + �^�C�g��
*/
/*
	UTILS �ėp
*/
// CSS �I�u�W�F�N�g�쐬
cmsSeriesList.set_css = function(path){
	var css = document.createElement('link');
	css.setAttribute('rel','stylesheet');
	css.setAttribute('type','text/css');
	css.setAttribute('media','all');
	css.setAttribute('href',path);
	return css;
};
// OID COUNT
cmsSeriesList.set_oidcount = function(e,scstr){
	return false;
	var atags = e.getElementsByTagName('a');
	for(var i = 0; i < atags.length; i++){
		atag2pos_oid(e,atags[i],scstr);
	}
	return;
};

function cmsSeriesList(data){

	// �A�ڐ�
	var dataL = data['items'].length;

	// �A�ڐ��� 1 ���̏ꍇ
	if(dataL == 1) return false;

	var d = document;
	if(data['closed'] == '1'){
		if(d.getElementById('msbBtnAlertseriesTop')) d.getElementById('msbBtnAlertseriesTop').style.display = 'none';
		if(d.getElementById('msbBtnAlertseriesBtm')) d.getElementById('msbBtnAlertseriesBtm').style.display = 'none';
	}

	// �{�����A�ڃA���[�g��\��
	// senna ��\��
	if(d.getElementById('cmsBody')){
		var cmsBody = d.getElementById('cmsBody');
		var cmsBodyDiv = cmsBody.getElementsByTagName('div');
		for(var i = 0; i < cmsBodyDiv.length; i++){
			if(cmsBodyDiv[i].className.indexOf('backNumBoxRap') != -1){
				cmsBodyDiv[i].style.display = 'none';
			}
			if(data['closed'] == '1'){
				if(cmsBodyDiv[i].className.indexOf('cmsBodyItmidSeriesButtonRegist') != -1){
					cmsBodyDiv[i].style.display = 'none';
				}
			}
		}
	}

	// CSS �ǂݍ���
	var css = cmsSeriesList.set_css('/css/cmsSeriesList.css');
	d.body.appendChild(css);

	var makeList = function(){
		var box = d.getElementById('cmsSeriesList');
		box.className = 'cmsSeriesList' + cmsSeriesList.makeIndex_pattern;
		if(d.getElementById('endlinkConnection')){
			d.getElementById('endlinkConnection').parentNode.insertBefore(box,d.getElementById('endlinkConnection'));
		}else if(d.getElementById('cmsCopyright')){
			d.getElementById('cmsCopyright').parentNode.insertBefore(box,d.getElementById('cmsCopyright'));
		}
		var html_header = '<article class="colBox seriesBoxClosed' + data['closed'] + '" id="seriesBox">';
		html_header += '<div class="colBoxOuter">';
		html_header += '<div class="colBoxHead">';
		if(data['icon']){
			html_header += '<div class="seriesBoxIcon"><a href="' + data['pcurl'] + '" style="background-image:url(' + imgSrv() + data['icon'] + ');"></a></div>';
		}else{
		}
		html_header += '<h1><a href="' + data['pcurl'] + '">' + data['title'] + ' �A�ڈꗗ</a></h1>';
		if(data['closed'] == '1'){
			html_header += '<div id="seriesBoxLength">�S ' + dataL + ' ��</div>';
		}else{
			html_header += '<div id="seriesBoxRegistbutton" onClick="document.getElementById(\'ITMIDalert2\').click();">����̌f�ڂ����[���Ŏ󂯎��</div>';
		}
		if(data['description']){
			html_header += '<h2>' + data['description'] + '</h2>';
		}
		html_header += '<div class="colBoxClear h0px"></div></div>';
		html_header += '<div class="colBoxInner"><div id="seriesIndexBox0"></div><div id="seriesIndexBox1">';
		var html_footer = '</div><div id="seriesIndexBox2"></div></div></div><div class="colBoxClear h10px"></div></article>';
		var html = '';

		var makeIndex = function(data,start,end){
			var html_contents = [];
			var html = '';
			for(var i = start; i < end; i++){
				if(data['items'][i]['pcurl'].match(path)){
					html = '<article id="colBoxIndex-' + i + '" class="colBoxIndex mycolBoxIndex">';
				}else{
					html = '<article id="colBoxIndex-' + i + '" class="colBoxIndex">';
				}
				html += '<div class="colBoxLeft">';
				if(data['items'][i]['icon'] == ''){
					html += '<div class="colBoxIcon noImg"><a href="' + data['items'][i]['pcurl'] + '"></a></div>';
				}else{
					html += '<div class="colBoxIcon"><a href="' + data['items'][i]['pcurl'] + '" style="background-image:url(' + imgSrv() + data['items'][i]['icon'] + ');"></a></div>';
				}
				html += '</div>';
				html += '<div class="colBoxRight">';
				html += '<hgroup class="colBoxHgroup">';
				if(i == 0){
					html += '<div class="colBoxTitle"><h1><a href="' + data['items'][i]['pcurl'] + '">' + data['items'][i]['title'] + '<span class="NewMark"></span></a></h1></div>';
				}else{
					html += '<div class="colBoxTitle"><h1><a href="' + data['items'][i]['pcurl'] + '">' + data['items'][i]['title'] + '</a></h1></div>';
				}
				html += '<div class="colBoxDescription"><h2>' + data['items'][i]['description'] + '</h2></div>';
				html += '</hgroup>';
				html += '<div class="colBoxInfo">';
				if(data['items'][i]['writers'].length != 0){
					html += '<span class="writer">';
					for(var j = 0; j < data['items'][i]['writers'].length; j++){
						html += '<a href="http://www.itmedia.co.jp/author/' + data['items'][i]['writers'][j]['id'] + '/">' + data['items'][i]['writers'][j]['name'] + '</a> ';
					}
					html += '</span>';
				}
				html += '(<time pubdate="pubdate" datatime="' + data['items'][i]['datetime'] + '" class="date">' + data['items'][i]['datetimej'] + '</time>)';
				html += '</div>';
				html += '</div>';
				html += '<div class="colBoxClear"></div>';
				html += '</article>';
				html_contents.push(html);
			}
			return html_contents.join('');
		}
		var makeIndex_1 = function(data,start,end){
			var html_contents = [];
			var html = '';
			var title = '';
			for(var i = start; i < end; i++){
				var myN = data['items'].length - i;
				title = data['items'][i]['title'].replace(/^��.*(��|�b|��)(\s|�@)/,'');
				if(data['items'][i]['pcurl'].match(path)){
					html = '<article id="colBoxIndex-' + i + '" class="colBoxIndex mycolBoxIndex">';
				}else{
					html = '<article id="colBoxIndex-' + i + '" class="colBoxIndex">';
				}
				html += '<div class="colBoxLeft N-' + String(myN).length + '">';
				html += '<div class="colBoxNumber">' + myN + '</div>';
				html += '</div>';
				html += '<div class="colBoxRight">';
				html += '<hgroup class="colBoxHgroup">';
				if(data['items'][i]['pcurl'].match(path)){
					html += '<div class="colBoxTitle"><h1>' + title + '</h1></div>';
				}else{
					html += '<div class="colBoxTitle"><h1><a href="' + data['items'][i]['pcurl'] + '">' + title + '</a></h1></div>';
				}
				html += '</hgroup>';
				html += '</div>';
				html += '<div class="colBoxClear"></div>';
				html += '</article>';
				html_contents.push(html);
			}
			return html_contents.join('');
		}
		html = html_header + html_footer;
		box.innerHTML = html;

		// �O��\����
		var range = 2;

		// �����\����
		var maxN = (range * 2) + 1; // 5

		// �����̈ʒu
		var thisN = 0;
		var path = getUrl()['path_cutpageing_cutparam'];
		if(cmsSeriesList.first_pattern == 1){
			for(var i = 0; i < dataL; i++){
				if(data['items'][i]['pcurl'].match(path)){
					thisN = i;
					break;
				}
			}
		}

		// �����W��`
		var thisRange = [];

		// �����\������\���ł��邩
		var viewFlag1st = false;
		if(dataL >= maxN){
			viewFlag1st = true;
		}else{
			viewFlag1st = false;
		}

		// �����̈ʒu�̑O�� range ���\���ł��邩
		var viewFlag1st_prev = false;
		if(thisN - range >= 0){
			viewFlag1st_prev = true;
		}else{
			viewFlag1st_prev = false;
		}

		// �����̈ʒu�̌��� range ���\���ł��邩
		var viewFlag1st_next = false;
		if(thisN + range <= dataL - 1){
			viewFlag1st_next = true;
		}else{
			viewFlag1st_next = false;
		}

		if(viewFlag1st == true){
			if(viewFlag1st_prev == true && viewFlag1st_next == true){
				thisRange[0] = thisN - range;
				thisRange[1] = thisN + range + 1;
			}else if(viewFlag1st_prev == true && viewFlag1st_next == false){
				thisRange[0] = dataL - maxN;
				thisRange[1] = dataL;
			}else if(viewFlag1st_prev == false && viewFlag1st_next == true){
				thisRange[0] = 0;
				thisRange[1] = maxN;
			}
		}else{
			thisRange = [0,dataL];
		}

		var box1 = d.getElementById('seriesIndexBox1');
		if(cmsSeriesList.makeIndex_pattern == 1){
			box1.innerHTML = makeIndex_1(data,thisRange[0],thisRange[1]);
		}else{
			box1.innerHTML = makeIndex(data,thisRange[0],thisRange[1]);
		}

		// �����̈ʒu�̑O��� range �ȏ�f�[�^�����邩
		var viewFlag = false;
		if(dataL > maxN){
			viewFlag = true;
		}else{
			viewFlag = false;
		}

		// �����̈ʒu�̑O�� range �ȏ�\���ł��邩
		var viewFlag_prev = false;
		if(thisN - range > 0){
			viewFlag_prev = true;
		}else{
			viewFlag_prev = false;
		}

		// �����̈ʒu�̌�� range �ȏ�\���ł��邩
		var viewFlag_next = false;
		if(thisN + range < dataL - 1){
			viewFlag_next = true;
		}else{
			viewFlag_next = false;
		}

		if(viewFlag == true){
			if(viewFlag_prev == true){
				var btn0 = d.createElement('div');
				var atag0 = d.createElement('a');
				btn0.className = 'colBoxButton';
				atag0.href = 'javascript:void(0);';
				atag0.innerHTML = '�V�����A�ڋL���� ' + thisRange[0] + ' ������܂�';
				btn0.appendChild(atag0);
				box1.insertBefore(btn0,box1.firstChild);
				var show0 = function(){
					deleteEventListener(atag0,'click',show0,false);
					btn0.parentNode.removeChild(btn0);
					var box0 = d.getElementById('seriesIndexBox0');
					if(cmsSeriesList.makeIndex_pattern == 1){
						box0.innerHTML = makeIndex_1(data,0,thisRange[0]);
					}else{
						box0.innerHTML = makeIndex(data,0,thisRange[0]);
					}
					box0.style.opacity = 1;
					cmsSeriesList.set_oidcount(box0,data['title']);
				};
				appendEventListener(atag0,'click',show0,false);
			}
			if(viewFlag_next == true){
				var btn2 = d.createElement('div');
				var atag2 = d.createElement('a');
				btn2.className = 'colBoxButton';
				atag2.href = 'javascript:void(0);';
				atag2.innerHTML = '�ߋ��̘A�ڋL���� ' + (dataL - thisRange[1]) + ' ������܂�';
				btn2.appendChild(atag2);
				box1.appendChild(btn2);
				var show2 = function(){
					deleteEventListener(atag2,'click',show2,false);
					btn2.parentNode.removeChild(btn2);
					var box2 = d.getElementById('seriesIndexBox2');
					if(cmsSeriesList.makeIndex_pattern == 1){
						box2.innerHTML = makeIndex_1(data,thisRange[1],dataL);
					}else{
						box2.innerHTML = makeIndex(data,thisRange[1],dataL);
					}
					box2.style.opacity = 1;
					cmsSeriesList.set_oidcount(box2,data['title']);
				};
				appendEventListener(atag2,'click',show2,false);
			}
		}

		// OID COUNT
		cmsSeriesList.set_oidcount(box1,data['title']);

	};

	// CSS �ǂݍ��݊�����\������
	appendEventListener(css,'load',makeList,false);
	return;
};
