/*=======================================================================*/
/* Utils */
/*=======================================================================*/
/*
	�u���E�U���������擾
*/
function getBrowserWH(){
	var win = window;
	var doc = document;
	if(win.innerWidth || win.innerHeight){
		return {'w':win.innerWidth,'h':win.innerHeight};
	}else if((doc.documentElement && doc.documentElement.clientWidth != 0) || (document.documentElement && document.documentElement.clientHeight != 0)){
		return {'w':doc.documentElement.clientWidth,'h':doc.documentElement.clientHeight};
	}else if(document.body){
		return {'w':doc.body.clientWidth,'h':doc.body.clientHeight};
	}
	return {'w':0,'h':0};
}
/*
	�u���E�U�X�N���[���ʎ擾
*/
function getBrowserScrollXY(){
	return {'x':document.documentElement.scrollLeft || document.body.scrollLeft,'y':document.documentElement.scrollTop || document.body.scrollTop};
}
/*
	�m�[�h�ʒu�擾
*/
function getElementXY(e){
	var x = 0;
	var y = 0;
	while(e){
		x += e.offsetLeft;
		y += e.offsetTop;
		e = e.offsetParent;
	}
	return {'x':x,'y':y};
};
/*
	�m�[�h���������擾
*/
function getElementWH(e){
	return {'w':e.offsetWidth,'h':e.offsetHeight};
};
/*
	�C�x���g
*/
var appendEventListener = function(elem,type,func,capture){
	var ret = null;
	if(elem.addEventListener){
		ret = func;
		elem.addEventListener(type,func,capture);
	}else if(elem.attachEvent){
		// ret = function(){
		// 	func.apply(elem,[elem.parentWindow.event]);
		// }
		ret = func;
		elem.attachEvent('on' + type,ret);
	}
	return ret;
};
var deleteEventListener = function(element,type,func,capture){
	if(element.removeEventListener){
		element.removeEventListener(type,func,capture);
	}else if(element.detachEvent){
		element.detachEvent('on' + type,func);
	}
};
/*
	�f�U�C���J�E���g�֐�
*/
function ds_count(pos,opt){
	if(!opt) var opt = '';
	// var a = 'spv_' + masterChannel + '_' + masterType + '_' + pos + ' ' + opt;
	var a = pos + ' ' + opt;
	s.prop14 = a;
	s.tl(this,'e',a);
	s_objectid = a;
	ds_test_log(a);
};
/*
	�f�U�C���J�E���g�֐��is ��`�j
*/
function ds_count_true(pos,opt){
	if(!opt) var opt = '';
	// var a = 'spv_' + masterChannel + '_' + masterType + '_' + pos + ' ' + opt;
	var a = pos + ' ' + opt;
	s = s_gi(s_account); 
	s.prop14 = a;
	s.tl(true,'o',a);
	s_objectid = a;
	ds_test_log(a);
};
/*
	�f�U�C���J�E���g�֐� OID
*/
function ds_count_oid(pos,opt){
	if(!opt) var opt = '';
	// var a = 'spv_' + masterChannel + '_' + masterType + '_' + pos + ' ' + opt;
	var a = pos + ' ' + opt;
	s.prop14 = a;
	s_objectID = a;
	ds_test_log(a);
};
/*
	���A����
	HOST + PATH1 �� REFERRER �ƈ�v���邩
*/
function ds_check_bounce(){
	var l = location;
	var f = false;
	var myHOST = l.host;
	var myPATH1 = l.pathname.split('/')[1];
	var myURL1 = myHOST + '/' + myPATH1 + '/';
	var myREF = document.referrer;
	if(myREF.indexOf(myURL1) != -1){
		f = true;
	}
	return f;
};
/*
	�e�X�g�p���O
*/
var ds_test_log = function(str){
	if(this.console && typeof console.log != 'undefined'){
		console.log(str);
	}
	return;
};
/*
	���R�����h�itaboola�j���擾
	�񓯊��̂��� 500ms ���� DOM ��T��
	10 ��܂Ń��g���C����
*/
var ds_tb_setoid = function(id){
	var d = document;
	var tb_count = 0;
	var tb_wait = setInterval(function(){
		// console.log('searching taboola...�F' + tb_count);
		tb_count++;
		if(d.getElementById(id).getElementsByTagName('a')[0]){
			var tb = d.getElementById(id);
			var atags = tb.getElementsByTagName('a');
			for(var i = 0; i < atags.length; i++){
				var atag = atags[i];
				atag2pos_oid(tb,atag);
			}
			clearInterval(tb_wait);
			// console.log('taboola set objectID');
		}else if(tb_count == 10){
			clearInterval(tb_wait);
			// console.log('not taboola');
		}
	},500);
};

/*=======================================================================*/
/* TEST */
/*=======================================================================*/
/*
	Cookie AB TEST
*/
var ds_ab_getcookie = function(name){
	if(!name) return '';
	var cookies = document.cookie.split('; ');
	for(var i = 0; i < cookies.length; i++){
		var str = cookies[i].split('=');
		if (str[0] != name) continue;
		return unescape(str[1]);
	}
	return '';
};
var ds_ab_flag = function(str){
	var f = false;
	var vid = ds_ab_getcookie('s_vid');
	var hs = location.hash;
	var regexp = new RegExp(str,'i');
	if(vid.match(regexp) || hs.match(regexp)){
		f = true;
	}
	return f;
};
/*
	taboola ���݊m�F
	�L�������R�����h�itaboola�j���擾
	�񓯊��̂��� 500ms ���� DOM ��T��
	10 ��܂Ń��g���C����
*/
var ds_tb_check = function(param){
	if(!param) return false;
	ds_test_log('ds_tb_check:Start taboola AB:scstr=' + param['scstr'] + '&viewthru=' + param['viewthru']);
	var scstr_load = param['scstr'] + '_load';
	var d = document;
	var tb_id = param['id'];
	var tb_count = 0;
	var tb_wait = setInterval(function(){
		ds_test_log('ds_tb_check:Searching taboola...�F' + tb_count);
		tb_count++;
		if(d.getElementById(tb_id).getElementsByTagName('a')[0]){
			clearInterval(tb_wait);
			// ds_test_log('ds_tb_check:Load taboola');
			// ds_count(scstr_load);
			// ds_test_log('ds_tb_check:SC Count (' + scstr_load + ')');
			if(param['viewthru'] == true){
				ds_viewthru(d.getElementById(tb_id),param['scstr']);
				ds_test_log('ds_tb_check:Set Viewthru');
			}
		}else if(tb_count == 10){
			clearInterval(tb_wait);
			ds_test_log('ds_tb_check:No taboola');
		}else{
			ds_test_log('ds_tb_check:Retry taboola');
		}
	},500);
};
/*
	�r���[�X���[
	elem = dom �̎w��
	scstr = SC �i�[�p������
*/
var ds_viewthru = function(elem,scstr,cri,offsetY){
	if(!cri) var cri = 'top';
	if(!offsetY) var offsetY = 0;
	var scstr_visible = scstr + '_visible';
	var checkview = function(e){
		var vf = false;
		var ws = getBrowserScrollXY()['y']; // SCROLL Y
		var bh = getBrowserWH()['h']; // WINDOW HEIGHT
		var ey = getElementXY(elem)['y']; // ELEMENT Y TOP
		var eh = getElementWH(elem)['h']; // ELEMENT HEIGHT
		var ec = ey; // ��_
		if(cri == 'bottom'){
			ec += eh;
		}
		if((ws + bh) > (ec + offsetY) && ws < (ey + eh)){
			ds_test_log('ds_viewthru:Element is visible (' + elem.id + ')');
			deleteEventListener(window,'scroll',checkview,false);
			ds_test_log('ds_viewthru:Scroll Event Delete');
			ds_count(scstr_visible);
			ds_test_log('ds_viewthru:SC Count (' + scstr_visible + ')');
			if(typeof ds_beforeunload_flag != 'undefined'){
				ds_beforeunload_evt(scstr);
				ds_beforeunload_evt_atag(elem);
				ds_test_log('ds_viewthru:ds_beforeunload_flag');
			}else{
				ds_test_log('ds_viewthru:ds_beforeunload_flag is not');
			}
		}else{
			ds_test_log('ds_viewthru:Element Not Visible (' + elem.id + ')');
		}
		return vf;
	};
	appendEventListener(window,'scroll',checkview,false);
	checkview();
	return;
};
/*
	�y�[�W�J�ڎ��� ds_beforeunload_flag �� 0 �̏ꍇ SC �J�E���g�iscstr�j���s��
*/
var ds_beforeunload_evt = function(scstr){
	var scstr_leave = scstr + '_leave';
	if(ds_check_bounce() == false){
		scstr_leave = scstr + '_bounce';
	}
	appendEventListener(window,'beforeunload',function(evt){
		if(ds_beforeunload_flag == 0){
			ds_count(scstr_leave);
			ds_test_log('ds_beforeunload_evt:SC Count (' + scstr_leave + ')');
		}
		// return false;
	},false);
	return;
};
/*
	�Ώۓ��� atag ���N���b�N�����ꍇ ds_beforeunload_flag �� 1 �ɂ���
*/
var ds_beforeunload_evt_atag = function(elem){
	var atag = elem.getElementsByTagName('a');
	for(var i = 0; i < atag.length; i++){
		appendEventListener(atag[i],'click',function(){
			ds_beforeunload_flag = 1;
		},false);
	}
	ds_test_log('ds_beforeunload_evt_atag:Attach Click Event ' + atag.length + ' Atag');
	return;
};
/*-------------------------------------------------------------------*/
/*
	�y�[�W�J�ڎ��� ds_beforeunload_flag �� SC �J�E���g�iscstr�j���s��
*/
var ds_beforeunload_evt_v2 = function(scstr){
	var scstr_leave = scstr + '_leave_';
	if(ds_check_bounce() == false){
		scstr_leave = scstr + '_bounce_';
	}
	appendEventListener(window,'beforeunload',function(evt){
		ds_count_true(scstr_leave + ds_beforeunload_flag);
		// ds_test_log('ds_beforeunload_evt_v2:SC Count (' + scstr_leave + ds_beforeunload_flag + ')');
		// return false;
	},false);
	return;
};
/*
	�Ώۓ��� atag ���N���b�N�����ꍇ ds_beforeunload_flag �� +1 �ɂ���
*/
var ds_beforeunload_evt_v2_atag = function(elem){
	var atag = elem.getElementsByTagName('a');
	for(var i = 0; i < atag.length; i++){
		appendEventListener(atag[i],'click',function(){
			ds_beforeunload_flag++;
			ds_test_log('ds_clickcount:' + ds_beforeunload_flag);
		},false);
	}
	ds_test_log('ds_beforeunload_evt_v2_atag:Attach Click Event ' + atag.length + ' Atag');
	return;
};
/*
	�Ώۓ��� atag �� target _blank �ɂ���
*/
var ds_blank_evt_atag = function(elem){
	var atag = elem.getElementsByTagName('a');
	for(var i = 0; i < atag.length; i++){
		atag[i].target = '_blank';
	}
	ds_test_log('ds_blank_evt_atag:Attach Click Event ' + atag.length + ' Atag');
	return;
};
