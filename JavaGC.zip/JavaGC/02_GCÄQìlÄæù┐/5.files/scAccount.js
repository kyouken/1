/* SiteCatslyst s_account
---------------------------------------------------------------------*/
function thisSite(){
	return 'itmediacojp' + 'global';
};
ThisSite = 'itmediacojp' + 'global';
