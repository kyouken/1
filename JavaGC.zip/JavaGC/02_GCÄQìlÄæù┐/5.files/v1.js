var cx_api_data = {"itm-r-k":"","itm-r-d":[],"itm-r-c":[],"itm-r-s":[],"itm-r-e":"","itm-r-m":""};
