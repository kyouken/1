
var IS_IEXPLORE = !!document.all;
var OPERA = !!window.opera;


function init(){
	adjustLayerPosition("topButton0" ,-77 ,-57);
}

function adjustLayerPosition(name ,offset_x ,offset_y){

	if(!window.adjustLayerPosition[name]){
		if(IS_IEXPLORE || OPERA){
			window.onscroll = init;
			window.onresize = init;
		}else{
			window.onresize = init;
		}
	}

	var point = getLayerPoint(offset_x ,offset_y);
	setLayerPosition(name ,point[0] ,point[1]);

	if(!IS_IEXPLORE){
		clearTimeout(adjustLayerPosition[name]);
		var script = "adjustLayerPosition('" + name + "'," + offset_x + "," + offset_y + ")";
		adjustLayerPosition[name] = setTimeout(script ,100);
	}

}

function getLayerPoint(offset_x ,offset_y){

	var point_x = 0;
	var point_y = 0;
	if(IS_IEXPLORE || OPERA){
		var body = document.body;
		point_x = offset_x + body.clientWidth + body.scrollLeft;
		point_y = offset_y + body.clientHeight + body.scrollTop;
	}else{
		point_x = offset_x + window.innerWidth + self.pageXOffset;
		point_y = offset_y + window.innerHeight + self.pageYOffset;
	}

	return new Array(point_x ,point_y);

}

function setLayerPosition(name ,point_x ,point_y){

	var object = document.getElementById(name);
	object.style.left = point_x;
	object.style.top = point_y;

}
