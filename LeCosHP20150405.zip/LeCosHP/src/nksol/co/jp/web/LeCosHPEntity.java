package nksol.co.jp.web;

public class LeCosHPEntity {

}
