package nksol.co.jp.web;

public class LeCosHPEnvironment {

    public LeCosHPEntity init(String type) {

        LeCosHPEntity entity = new LeCosHPEntity();

        // ------------------------
        // 共通
        // ------------------------

        // ------------------------
        // 個別設定
        // ------------------------

        if (type.equals("LT")) {

        } else if (type.equals("ST")) {

        } else if (type.equals("ST1")) {

        } else if (type.equals("JH")) {

        } else if (type.equals("UAT")) {

        }

        return entity;

    }

}
