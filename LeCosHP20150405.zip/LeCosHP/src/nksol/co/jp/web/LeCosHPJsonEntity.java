package nksol.co.jp.web;

/**
 *
 * @author tsujii
 *
 */
public class LeCosHPJsonEntity {

    /** */
    private String value;

    /** */
    private String cssColor;

    // -----------------------------------
    // setter / getter
    // -----------------------------------
    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getCssColor() {
        return cssColor;
    }

    public void setCssColor(String cssColor) {
        this.cssColor = cssColor;
    }

}
