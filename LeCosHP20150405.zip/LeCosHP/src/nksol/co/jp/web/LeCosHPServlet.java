package nksol.co.jp.web;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.arnx.jsonic.JSON;
import nksol.co.jp.web.ssh.LeCosCommandExecutor;

/**
 * LeCos開発者用のHPのServlet。
 *
 * @author NKSOL a-tsujii
 * @since 2015-04
 *
 */
@WebServlet(urlPatterns = { "/*" })
public class LeCosHPServlet extends HttpServlet {

    /** デフォルトシリアル番号 */
    private static final long serialVersionUID = 1L;

    /*
     * (非 Javadoc)
     *
     * @see
     * javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest
     * , javax.servlet.http.HttpServletResponse)
     */
    @Override
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }

    /*
     * (非 Javadoc)
     *
     * @see
     * javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest
     * , javax.servlet.http.HttpServletResponse)
     */
    @Override
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {

        // URLからTypeを取得
        String urlStr = request.getRequestURI();
        try {
            urlStr = urlStr.split("/")[2];
        } catch (Exception e) {
            return;
        }

        // 初期処理
        LeCosHPEntity entity = (new LeCosHPEnvironment()).init(urlStr);

        // コマンド実行
        (new LeCosCommandExecutor()).exec(entity);

        // JSON書き込み
        response.setContentType("application/json; charset=UTF-8");
        List<LeCosHPJsonEntity> list = new ArrayList<LeCosHPJsonEntity>();
        for (int i = 0; i < 6; i++) {
            LeCosHPJsonEntity json = new LeCosHPJsonEntity();
            json.setValue("起動中");
            json.setCssColor(null);
            list.add(json);
        }
        String jsonStr = JSON.encode(list, true);
        response.getOutputStream().write(jsonStr.getBytes("UTF-8"));

    }

}