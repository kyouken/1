package nksol.co.jp.web.dao;

public class LeCosSelectDao {

}
