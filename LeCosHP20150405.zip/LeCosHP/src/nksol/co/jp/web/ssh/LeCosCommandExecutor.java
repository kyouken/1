package nksol.co.jp.web.ssh;

import nksol.co.jp.web.LeCosHPEntity;

public class LeCosCommandExecutor {

    public void exec(LeCosHPEntity entity) {

    }

}
