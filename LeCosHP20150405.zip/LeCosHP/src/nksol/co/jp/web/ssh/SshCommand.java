package nksol.co.jp.web.ssh;

public class SshCommand {

}
