
//---------------------------------------------------
// Function
//---------------------------------------------------
function transportFunction ( urlStr , selectaStr) {
    jQuery.support.cors = true;

    $.ajax({
      url: urlStr,
      dataType: 'json',
      cache: false,
      timeout: 10000,

      success: function(json){
        //TODO JSON Format
        $(selectaStr + '1').append(json[0].value).css("color",json[0].cssColor);
        $(selectaStr + '2').append(json[1].value).css("color",json[1].cssColor);
        $(selectaStr + '3').append(json[2].value).css("color",json[2].cssColor);
        $(selectaStr + '4').append(json[3].value).css("color",json[3].cssColor);
        $(selectaStr + '5').append(json[4].value);
        $(selectaStr + '6').append(json[5].value);
      },

      error: function(xhr, textStatus, errorThrown){
        alert('Error! ' + textStatus + ' ' + errorThrown);
      }

    });

}


//---------------------------------------------------
// Ready Method
//---------------------------------------------------
var URL = "http://localhost:28080/LeCosHP"

$(function(){
    transportFunction( URL + '/LT' , '#divLT');
});

$(function(){
    transportFunction( URL + '/ST' , '#divST');
});

$(function(){
    transportFunction( URL + '/ST2' , '#divST2');
});

$(function(){
    transportFunction( URL + '/JH' , '#divJH');
});

$(function(){
    transportFunction( URL + '/UAT' , '#divUAT');
});




