$(document).ready(function() {
    $("#tv").treeview({
		control: "#treecontrol",
   		animated: "fast",
		collapsed: true,
		unique: false,
		persist: "location"
    });
});
