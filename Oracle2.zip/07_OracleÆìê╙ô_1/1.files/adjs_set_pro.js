(function(window, undefined){
  try {
    var params = "";
    var endtime_p = 0;
    var intervalGetCategorys = setInterval(function() {
      var categories = document.getElementsByClassName("tagIcon_name");
      if (typeof categories !== "undefined") {
        for (var i = 0; i < categories.length; i++) {
          if (i != 0) {
            params += ",";
          }
          params += categories[i].innerHTML;
        }
      }
      ++endtime_p;
      if (params !== "" || endtime_p > 30) {
        clearInterval(intervalGetCategorys);
        //text-header:18, text-footer:19, banner-right-16
        var script = document.createElement("script");
        script.src = '//qiita-proxy.bigmining.com/js/adrequest_pro.js?zones=18|19|16&cat=' + params.toLowerCase() + '&r=' + Math.floor(Math.random() * 99999999);
        document.body.appendChild(script);
      }
    }, 50);

    // banner risize trigger
    var ad = "";
    var endtime_a = 0;
    var intervalSetResize = setInterval(function() {
      var ad_elements = document.getElementsByClassName("bm_ad_text");
      if (typeof ad_elements !== "undefined") {
        if (ad_elements.length > 0) {
          adResize();
          clearInterval(intervalSetResize);
        }
      }
      ++endtime_a;
      if (endtime_a > 50) {
        clearInterval(intervalSetResize);
      }
    }, 100);


    // page render action
    function adResize(){
      function setStyle(elms, sObj) {
        try {
          for(var i = 0, j = elms.length; i < j; i++) {
            for(var c in sObj) {
              elms[i].style[c] = sObj[c];
            }
          }
        } catch (e) {
        }
      }
      function setBefore() {
        try {
          document.getElementById("bm_ad_text_sub").style.display="";
          document.getElementsByClassName("bm_ad_text")[0].style.height="64px";
          document.getElementsByClassName("bm_ad_text")[1].style.height="64px";
          document.getElementById("bm_ad_category").style.display="";
          var t_title = document.getElementsByClassName("bm_ad_title_back");
          setStyle(t_title, {
            display: "",
            margin: "0px 0px 0px 10px",
          });
        } catch (e) {
        }
      }
      try {
        if (window.matchMedia("(max-width:767px)").matches) {
          setBefore();
        } else if (window.matchMedia("(max-width:991px)").matches) {
          document.getElementsByClassName("bm_ad_text")[0].style.height="96px";
          document.getElementsByClassName("bm_ad_text")[1].style.height="96px";
          //document.getElementById("bm_ad_subtitle").style.display="none";
          document.getElementById("bm_ad_text_sub").style.display="none";
          document.getElementById("bm_ad_category").style.display="none";
          var t_title = document.getElementsByClassName("bm_ad_title_back");
          setStyle(t_title, {
            display: "block",
            margin: "0px 10px 0px 10px",
          });
        } else if (window.matchMedia("(max-width:1199px)").matches) {
          setBefore();
          document.getElementById("bm_ad_category").style.display="none";
        } else {
          setBefore();
        }
      } catch (e) {
      }
    }

    window.addEventListener('resize', function(){
      function setStyle(elms, sObj) {
        try {
          for(var i = 0, j = elms.length; i < j; i++) {
            for(var c in sObj) {
              elms[i].style[c] = sObj[c];
            }
          }
        } catch (e) {
        }
      }
      function setBefore() {
        try {
          document.getElementById("bm_ad_text_sub").style.display="";
          document.getElementsByClassName("bm_ad_text")[0].style.height="64px";
          document.getElementsByClassName("bm_ad_text")[1].style.height="64px";
          document.getElementById("bm_ad_category").style.display="";
          var t_title = document.getElementsByClassName("bm_ad_title_back");
          setStyle(t_title, {
            display: "",
            margin: "0px 0px 0px 10px",
          });
        } catch (e) {
        }
      }

      try {
        if (window.matchMedia("(max-width:767px)").matches) {
          setBefore();
        } else if (window.matchMedia("(max-width:991px)").matches) {
          document.getElementsByClassName("bm_ad_text")[0].style.height="96px";
          document.getElementsByClassName("bm_ad_text")[1].style.height="96px";
          //document.getElementById("bm_ad_subtitle").style.display="none";
          document.getElementById("bm_ad_text_sub").style.display="none";
          document.getElementById("bm_ad_category").style.display="none";
          var t_title = document.getElementsByClassName("bm_ad_title_back");
          setStyle(t_title, {
            display: "block",
            margin: "0px 10px 0px 10px",
          });
        } else if (window.matchMedia("(max-width:1199px)").matches) {
            setBefore();
            document.getElementById("bm_ad_category").style.display="none";
        } else {
            setBefore();
        }
      } catch (e) {
      }
    }, false);
  } catch (e) {
  }
})(this);