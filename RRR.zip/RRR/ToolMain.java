import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

public class ToolMain {

	public static void main(String[] args) {

		ToolMain obj = new ToolMain();
		obj.execute();

	}

	private void execute() {

		try {
			FileReader fr = new FileReader(new File("fee.txt"));
			FileWriter fw = new FileWriter(new File("out.txt"));

			BufferedReader br = new BufferedReader(fr);
			String line = null;
			while ((line = br.readLine()) != null) {
				String[] array = line.split(",");

				fw.write(array[0] + "," + array[1] + "," + array[2] + "," + array[3] + "," + array[4] + "," + array[5]
						+ "," + array[6] + "," + array[7] + "," + array[8] + "," + array[9] + "," + array[10] + ","
						+ array[11] + "," + array[12] + "\n");
			}

			fw.flush();
			fw.close();
			fr.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

