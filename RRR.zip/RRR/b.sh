
count=1

rm -f output.txt

while true ; do
    cat RiskOrigin.txt >> output.txt 
    count=`expr $count + 1`
    if [ ${count} -ge 10000000 ] ; then
        break;
    fi
done


