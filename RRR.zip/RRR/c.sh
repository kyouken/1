
rm -f hoge.txt

echo `date` >> time.txt

while read line ; do

echo $line | awk -F, '{print $1","$2","$3","$4","$5","$6","$7","$8","$9","$10","$11","$12","$1","$2","$3}' tmp2 > hoge.txt

usleep 1000000 

done < tmp2


echo `date` >> time.txt

