window.addEventListener('load', function() {
    (function($) {
        var navDiv = $("#nav"), nav;
        //$.get(location.href.match(/^[https?]+:\/{2,3}([0-9a-zA-Z\.\-:]+?):?[0-9]*?\//i) + 'menu.html', function(response) {
        $.get('/menu.html', function(response) {
            nav = navDiv.html(response).mmenu({
                offCanvas: {
                    position: "right"
                }
            }).data('mmenu');
        });
        $(document).on('click', function(e) {
            if($('#html').hasClass('mm-opened')) {
                if($(e.target).is('#blocker') || $(e.target).is('body')) {
                    return false;
                } else {
                    if($(e.target).parents('#nav').length < 1) {
                        nav.close();
                    }
                }
            }
            if(e.target.href && e.target.hash && e.target.hash.indexOf('#mm') === -1) {
                if(e.target.hash != '#nav' && e.target.href.replace(e.target.hash, '') == location.href.replace(location.hash, '')) {
                    nav.close();
                }
            }
        });

        var timer, y,
            body = $('body'),
            windowWidth = $(window).width(),
            windowHeight = $(window).height(),
            contentHeight = document.body.clientHeight,
            fixHeader = $('#fixHeader'),
            fixStart = fixHeader.offset().top,
            scroller = $('#scroller'),
            footer = $('#footer'),
            footerOffset = footer.offset().top;

        if(windowWidth < 768) {
            fixStart = 54;
        }

        $(window).on('scroll', function() {
            clearTimeout(timer);
            timer = setTimeout(function() {
                y = $(window).scrollTop();
                if(y >= fixStart){
                    body.addClass('header-fixed');
                }else{
                    body.removeClass('header-fixed');
                }

                fixScroller();
            }, 1);
        });

        function fixScroller() {
            if(contentHeight > windowHeight) {
                if(windowHeight > y) {
                    body.removeClass('scroller-fixed');
                } else if(footerOffset - windowHeight < y ) {
                    body.addClass('scroller-bottom');
                } else {
                    body.addClass('scroller-fixed');
                    body.removeClass('scroller-bottom');
                }
            }
        }

        scroller.on('click', function() {
            $("html, body").stop().animate({ scrollTop: 0 }, 600);
        });

        /**
         * scroll to anchor
         */
        $('a[href^=#]').not('a[href=#nav]').not('a[href^=#mm]').each(function() {
            var self = $(this),
                target = $(self.attr('href'));

            if($(target).length > 0) {
                self.on('click', function() {
                    position = $(target).offset().top - 74;
                    $("html, body").animate({scrollTop:position}, 500, "swing");
                    return false;
                });
            }
        });

        /**
         * reference page menu position
         */
        if($('.header-middle').length > 0) {
            $('#nav').css({top: fixStart + 54});
            $('#overlay').css({top: fixStart + 54});

            $(window).on('scroll', function() {
                clearTimeout(timer);
                timer = setTimeout(function() {
                    var scroll = $(window).scrollTop();
                    $('#nav').css({top: fixStart + 54 - scroll});
                    $('#overlay').css({top: fixStart + 54 -scroll});
                }, 1);
            });
        }

        /**
         * for lt IE9 placeholder
         */
        if($('#html').hasClass('ie9')) {
            $('input[type=text], input[type=email], textarea').each(function() {
                var self = $(this),
                    ph = self.attr("placeholder");

                if(ph == null || !ph.length) {
                    return;
                }

                if(!self.val().length) {
                    self.val(ph);
                    self.css("color", "#999");
                }
                self.focus(function() {
                    if(self.val() == ph) {
                        self.val("");
                        self.css("color", "#3F4D5A");
                    }
                }).blur(function() {
                    if(self.val() == "") {
                        self.val(ph);
                        self.css("color", "#999");
                    }
                }).parents('form').on('submit', function(e) {
                    if(self.val() == ph) {
                        self.val('');
                    }
                });
            });
            $('input[type=password]').each(function() {
                var self = $(this),
                    ph = self.next('.placeholder');

                if(!ph.length) {
                    return;
                }

                if(!self.val().length) {
                    ph.css('display', 'block');
                }
                self.focus(function() {
                    ph.hide();
                }).blur(function() {
                    if(self.val() == "") {
                        ph.css('display', 'block');
                    }
                });
                ph.click(function() {
                    self.focus();
                });
            });
        }
    })(jQuery);
});