package com.sample.dao;

import com.sample.form.User;

public interface UserSelectDao {

    public User selectId(String id);

}
