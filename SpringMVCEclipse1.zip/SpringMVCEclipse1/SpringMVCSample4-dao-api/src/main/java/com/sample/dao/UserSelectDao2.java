package com.sample.dao;

import com.sample.form.User;

public interface UserSelectDao2 {

    public User selectId(String id);

}
