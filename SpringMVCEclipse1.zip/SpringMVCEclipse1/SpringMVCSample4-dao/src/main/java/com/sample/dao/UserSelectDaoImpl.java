package com.sample.dao;

import org.springframework.stereotype.Repository;

import com.sample.form.User;

@Repository
public class UserSelectDaoImpl implements UserSelectDao {

    @Override
    public User selectId(String id) {

        // FIXME ここは本当はDBを利用する
        User user = new User();

        user.setId(id + "_Daoから取得");
        user.setId(id + "_Name");

        return user;
    }

}
