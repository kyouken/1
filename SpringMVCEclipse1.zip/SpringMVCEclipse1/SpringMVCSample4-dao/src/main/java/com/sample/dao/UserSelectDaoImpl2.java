package com.sample.dao;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.sample.form.User;

@Scope("prototype")
@Repository
public class UserSelectDaoImpl2 implements UserSelectDao2 {

    @Override
    public User selectId(String id) {

        // FIXME ここは本当はDBを利用する
        User user = new User();

        user.setId(id + "_Dao2から取得");
        user.setId(id + "_Name2");

        return user;
    }

}
