package com.sample.business.service;

import com.sample.form.User;

/**
 *
 * @author tsujii
 *
 */
public interface UserFindService {

    /**
     *
     * @param id
     * @return
     */
    public User find(String id);

}
