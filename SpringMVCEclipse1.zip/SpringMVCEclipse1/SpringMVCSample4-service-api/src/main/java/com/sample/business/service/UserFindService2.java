package com.sample.business.service;

import com.sample.form.User;

/**

 * @author tsujii
 *
 */
public abstract class UserFindService2 {

    /**
     *
     * @param id
     * @return
     */
    public abstract User find(String id);

}
