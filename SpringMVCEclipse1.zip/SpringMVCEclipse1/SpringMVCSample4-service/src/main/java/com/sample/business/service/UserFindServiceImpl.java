package com.sample.business.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.sample.dao.UserSelectDao;
import com.sample.form.User;

@Scope("prototype")
@Component
public class UserFindServiceImpl implements UserFindService {

    @Autowired
    UserSelectDao dao;

    @Override
    public User find(String id) {

        User user = dao.selectId(id);

        return user;
    }

}
