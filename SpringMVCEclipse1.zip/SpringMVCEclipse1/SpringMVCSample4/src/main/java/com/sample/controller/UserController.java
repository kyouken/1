package com.sample.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.sample.business.service.UserFindService2;
import com.sample.form.User;

@Component
public class UserController {

    @Autowired
    private UserFindService2 service;

    public void doGet() {

        String id = "100";

        User user = service.find(id);

        System.out.println("id = " + user.getId());
        System.out.println("name = " + user.getName());
    }

    // ---------------------------------------------
    public static void main(String[] args) {

        ApplicationContext appContext = new ClassPathXmlApplicationContext(
                "ApplicationContext.xml");

        UserController main = appContext.getBean(UserController.class);
        main.doGet();
    }

}
