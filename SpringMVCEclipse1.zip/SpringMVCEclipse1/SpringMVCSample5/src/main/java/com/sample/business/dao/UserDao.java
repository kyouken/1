package com.sample.business.dao;

import com.sample.business.model.User;

public interface UserDao {

    public void update(User user);

    public User selectId(String userId);

}
