package com.sample.business.dao;

import java.util.Date;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.sample.business.model.User;

@Scope("prototype")
@Repository
public class UserDaoImpl implements UserDao {

    @Override
    public void update(User user) {

        // FIXME 本当は、DBへupdateする

    }

    @Override
    public User selectId(String userId) {

        // FIXME 本当は、DBから取得する
        User user = new User();
        user.setId(userId);
        user.setName("Name" + userId);
        user.setAge(20);
        user.setUpDate(new Date());

        return user;
    }

}
