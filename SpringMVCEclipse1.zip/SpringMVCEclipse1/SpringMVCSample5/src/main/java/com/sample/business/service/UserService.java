package com.sample.business.service;

import com.sample.business.model.User;

public interface UserService {

    public void updateUser(User user);

    public User getUser(String id);

}
