package com.sample.business.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sample.business.dao.UserDao;
import com.sample.business.model.User;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserDao dao;

    @Override
    public void updateUser(User user) {

        this.dao.update(user);

    }

    @Override
    public User getUser(String id) {

        User user = this.dao.selectId(id);



        return user;
    }

}
