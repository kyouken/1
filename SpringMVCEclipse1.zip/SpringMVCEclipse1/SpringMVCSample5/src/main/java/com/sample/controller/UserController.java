package com.sample.controller;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.sample.business.model.User;
import com.sample.business.service.UserService;
import com.sample.form.Form;

@Controller
@RequestMapping(value = "/user")
public class UserController {

    @Autowired
    private UserService userService;

    // ------------------------------------------------------
    // @RequestMapping (リクエスト処理)
    // ------------------------------------------------------
    @RequestMapping(value = "edit/input", method = RequestMethod.GET)
    public String input(Form form) {

        // 既に@ModelAttributeの処理で、モデルをDBから取り出して、formに設定してうるので
        // ここでは特に処理をする必要はない。

        return "user-Edit-Input";
    }

    @RequestMapping(value = "edit/confirm", method = RequestMethod.POST)
    public String confirm(@Valid Form form, BindingResult result) {

        // バリデーションでエラーになった場合は、user-Edit-Input.jspへ遷移
        if (result.hasErrors()) {
            return "user-Edit-Input";
        }

        return "user-Edit-Confirm";
    }

    @RequestMapping(value = "edit/finish", method = RequestMethod.POST)
    public String finish(@Valid Form form, BindingResult result) {

        // バリデーションでエラーになった場合は、user-Edit-Input.jspへ遷移
        if (result.hasErrors()) {
            return "user-Edit-Input";
        }

        this.userService.updateUser(form.getUser());

        return "user-Edit-Finish";
    }

    // ------------------------------------------------------
    // @ModelAttribute
    // ------------------------------------------------------
    /**
     * リクエストフォームとして送られてきたuserIdを元に、最新のUserデータを取得し、設定する処理.
     *
     * 実際は、BussinessLogin経由でDBから値を取っている。
     *
     * @param userId
     * @return
     */
    @ModelAttribute("form")
    public Form newRequest(
            @RequestParam(required = false, value = "user.id") String userId) {

        Form form = new Form();

        User user = null;
        if (userId == null) {
            // id指定がなければ、新規にNewする
            user = new User();
        } else {
            // DBより最新のUserデータを取得する
            user = this.userService.getUser(userId);
        }

        form.setUser(user);

        return form;
    }

    // ------------------------------------------------------
    // @InitBinder
    // ------------------------------------------------------
    /**
     * formモデルのバインダー初期化メソッド。
     *
     * リクエストパラメタをモデルに変換するたびに、前処理として呼ばれる。
     *
     * @param binder
     */
    @InitBinder("form")
    public void initBinderForm(WebDataBinder binder) {

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");

        // binderする際の、Date型の変換はこのようにする。
        binder.registerCustomEditor(Date.class, "user.upDate",
                new CustomDateEditor(dateFormat, true));

        // Userオブジェクトの内、user.nameパラメタを受け取りたくない場合
        binder.setAllowedFields("user.age", "user.upDate");
    }

}
