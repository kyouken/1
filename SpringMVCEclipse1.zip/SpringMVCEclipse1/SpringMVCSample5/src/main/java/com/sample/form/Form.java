package com.sample.form;

import java.io.Serializable;

import javax.validation.Valid;

import com.sample.business.model.User;

public class Form implements Serializable {

    @Valid
    private User user;

    // --------------------------------
    // setter / getter
    // --------------------------------

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
