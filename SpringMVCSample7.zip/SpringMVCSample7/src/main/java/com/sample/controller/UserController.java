package com.sample.controller;

import javax.servlet.http.HttpSession;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.sample.form.SampleForm;

@Scope("request")
@Controller
@RequestMapping(value = "/user")
public class UserController {

    /**
     *
     * @param sampleForm
     * @param session
     * @return
     */
    @RequestMapping(value = "child", method = RequestMethod.POST)
    public String child(SampleForm sampleForm, HttpSession session, Model model) {

        session.setAttribute("name", "ValueSession");

        System.out
                .println("childメソッドは通りましたよ / sessionのnameキーに、値=ValueSessionを追加");

        sampleForm.setName("Init Value");

        model.addAttribute(sampleForm);

        return "child";
    }

    /**
     *
     * @param sampleForm
     * @param session
     * @param model
     * @return
     */
    @RequestMapping(value = "close", method = RequestMethod.POST)
    public String close(SampleForm sampleForm, HttpSession session, Model model) {

        sampleForm.setName((String) session.getAttribute("name"));

        System.out.println("closeメソッドは通りましたよ / sampleForm.getName()="
                + sampleForm.getName());

        model.addAttribute(sampleForm);

        return "index";

    }

}
