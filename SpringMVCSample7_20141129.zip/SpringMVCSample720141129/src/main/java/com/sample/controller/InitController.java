package com.sample.controller;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sample.form.SampleForm;

@Scope("request")
@Controller
public class InitController {

    @RequestMapping(value = "/")
    public String init(SampleForm sampleForm) {

        return "index";
    }

    @RequestMapping(value = "/redirect")
    public String redirect(SampleForm sampleForm) {

        return "redirect";
    }
}
