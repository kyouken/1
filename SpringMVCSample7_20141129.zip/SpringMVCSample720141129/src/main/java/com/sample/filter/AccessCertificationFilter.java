package com.sample.filter;

import java.io.IOException;
import java.util.Date;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;

import org.springframework.context.annotation.Scope;

@Scope("request")
@WebFilter(urlPatterns = { "/*" })
public class AccessCertificationFilter implements Filter {

    public void doFilter(ServletRequest request, ServletResponse response,
            FilterChain chain) throws IOException, ServletException {

        try {
            Date date = new Date();

            System.out.println("#### Filterを通りまくり / Date = "
                    + date.toLocaleString());

            if (date.getTime() % 3 == 0) {
                System.out.println("#### ばっちりリダイレクト対象です");

                System.out.println("@@@@@ ContextPath = "
                        + request.getServletContext().getContextPath()
                        + "/redirect");

                // redirectでOKっぽい？？
                RequestDispatcher rd = request
                        .getRequestDispatcher("/redirect");
                rd.forward(request, response);

            }

        } catch (Exception e) {
            throw new ServletException(e);
        }

        chain.doFilter(request, response);
    }

    @Override
    public void destroy() {
        // nothing
    }

    @Override
    public void init(FilterConfig arg0) throws ServletException {
        // nothing
    }

}