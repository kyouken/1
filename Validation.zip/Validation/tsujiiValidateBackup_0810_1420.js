$(function() {

    $(".btn").on('click', function() {
        var flag = true;

        if ( $("#dialog li") ) { 
             $("#dialog li").remove();
        }

        $(".requiredText").each(function() {
           var nameValue = $(this).attr('name');
           var textValue = $(':text[name=' + nameValue + ']').val();
           if ( ! textValue ) {
               $(this).css('border','1px solid red');
               flag = false;
           } else {
               $(this).css('border','1px solid #e6e6e6');
           }
        });

        if ( flag == false) { 
            $("#dialog ul").after("<li>必須項目が入力されていません。</li>");

            $('#dialog').dialog({
                modal: true
            });
        }

        $(this).blur();

        return flag;
    });    
});


