
$(function() {

    $(".btn").on('click', function() {

        var flag = true;
        $(".requiredText").each(function() {
           var nameValue = $(this).attr('name');
           var textValue = $(':text[name=' + nameValue + ']').val();
           if ( ! textValue ) {
               $(this).css('border','2px solid red');
               flag = false;
           }
        });
        $(this).blur();

        return flag;
    });


    /*  return false�ł悩�����Ȃ�āE�E�E */
    /*---------------------------------
    $(".btn").click(function(){
        $('#hoge').css('color', '#0000FF');
        alert("OK");
        return false;
    });
    --------------------------------------*/



    /* onClick �ł͂��̒������Œ����Ă��܂� */
    /*
    var arr = [];

    $(".btn").on('click', function() {
        arr.push( $(":text[name=Name]") ); 
        $(':text[name=Name]').css('border','2px solid red');
        alert("before=" + arr.length);
    });
    */


    /*
    var $changeArray = new Array('');
    var $unchangeArray = new Array('');

    $(".btn").on('click', function() {
        $(".requiredText").each(function() {
           var nameValue = $(this).attr('name');
           var textValue = $(':text[name=' + nameValue + ']').val();
           if ( ! textValue ) {
               var $changeArray = $changeArray.push(':text[name=' + nameValue + ']');
               alert($changeArray);
           } else {

           }
        });
        $(this).blur();
    });
    

    jQuery.each($changeArray, function() {
       $(this).addClass('.haserrors');
    });
    */

    /*   Click�͂��܂������Ă���    */
    /*--------------------------------
    $(".btn").on('click', function() {
        alert("gee");
        $(this).blur();
    });
    ----------------------------------*/

    /*  ���ꂾ��btn��toggle�������Ă��� */
    /*-------------------------------
    $(".btn").toggle(
        function() {
            $(".requiredText").each(function() {
               var nameValue = $(this).attr('name');
               var textValue = $(':text[name=' + nameValue + ']').val();
               if ( ! textValue ) {
                   $(this).css('border','2px solid red');
                   $(".btn").css("display","block");
               }
            });
        },
        function() {
            $(".requiredText").each(function() {
               var nameValue = $(this).attr('name');
               var textValue = $(':text[name=' + nameValue + ']').val();
               if ( ! textValue ) {
                   $(this).css('border','1px dotted black');
                   $(".btn").css("display","block");
               }
            });
        }
    );
    -------------------------------*/



    /*  ���ꂾ�ƃN���b�N�����u�Ԃɏ����Ă��܂� */
    /*-------------------------------
    $(".btn").click(function() {
        $(".requiredText").each(function() {
           var nameValue = $(this).attr('name');
           var textValue = $(':text[name=' + nameValue + ']').val();
           if ( ! textValue ) {
               $(this).css('border','2px solid red');
           }
        });
    });
    -------------------------------*/


    /* ����� animal�̒��ɂ� �e�L�X�g�̕����������Ă���
       ������Null���ǂ����ŐF��ς���                  */
    /*-------------------------------
    $(".btn").click(function() {
        $(".requiredText").each(function() {
           var animal = $(':text[name="Name"]').val();
           alert(animal);
        });
    
    });
    -------------------------------*/


    /* CSS�̐F�̕ς��� */
    /*$(this).css('border','2px solid red');*/
    
});



