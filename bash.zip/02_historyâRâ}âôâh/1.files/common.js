//画面を閉じる
function closeWindow(){
	window.close();
}

//Shift_JIS(JA16SJIS)に対する変換マッピングの不整合
//var moji1 = "￠￡￢∥－～＆";
var moji1 = "￠￡∥－～＆";

//半角カナ
var moji2 = "｡｢｣､･ｦｧｨｩｪｫｬｭｮｯｰｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎﾏﾐﾑﾒﾓﾔﾕﾖﾗﾘﾙﾚﾛﾜﾝﾞﾟ";

//HTMLタグ
var moji3 = "<";

//13区
var moji4 = "①②③④⑤⑥⑦⑧⑨⑩⑪⑫⑬⑭⑮⑯⑰⑱⑲⑳ⅠⅡⅢⅣⅤⅥⅦⅧⅨⅩ㍉㌔㌢㍍㌘㌧㌃㌶㍑㍗㌍㌦㌣㌫㍊㌻㎜㎝㎞㎎㎏㏄㎡㍻〝〟№㏍℡㊤㊥㊦㊧㊨㈱㈲㈹㍾㍽㍼≒≡∫∮∑√⊥∠∟⊿∵∩∪";

//その他の使用禁止文字 2005-08-29 sasaki add
var moji5 = '\\\\"' + ">;'";

//89～92区
var block = new Array(
"\u7E8A","\u891C","\u9348","\u9288","\u84DC","\u4FC9","\u70BB","\u6631","\u68C8","\u92F9",
"\u66FB","\u5F45","\u4E28","\u4EE1","\u4EFC","\u4F00","\u4F03","\u4F39","\u4F56","\u4F92",
"\u4F8A","\u4F9A","\u4F94","\u4FCD","\u5040","\u5022","\u4FFF","\u501E","\u5046","\u5070",
"\u5042","\u5094","\u50F4","\u50D8","\u514A","\u5164","\u519D","\u51BE","\u51EC","\u5215",
"\u529C","\u52A6","\u52C0","\u52DB","\u5300","\u5307","\u5324","\u5372","\u5393","\u53B2",
"\u53DD","\uFA0E","\u549C","\u548A","\u54A9","\u54FF","\u5586","\u5759","\u5765","\u57AC",
"\u57C8","\u57C7","\uFA0F","\uFA10","\u589E","\u58B2","\u590B","\u5953","\u595B","\u595D",
"\u5963","\u59A4","\u59BA","\u5B56","\u5BC0","\u752F","\u5BD8","\u5BEC","\u5C1E","\u5CA6",
"\u5CBA","\u5CF5","\u5D27","\u5D53","\uFA11","\u5D42","\u5D6D","\u5DB8","\u5DB9","\u5DD0",
"\u5F21","\u5F34","\u5F67","\u5FB7",

"\u5FDE","\u605D","\u6085","\u608A","\u60DE","\u60D5","\u6120","\u60F2","\u6111","\u6137",
"\u6130","\u6198","\u6213","\u62A6","\u63F5","\u6460","\u649D","\u64CE","\u654E","\u6600",
"\u6615","\u663B","\u6609","\u662E","\u661E","\u6624","\u6665","\u6657","\u6659","\uFA12",
"\u6673","\u6699","\u66A0","\u66B2","\u66BF","\u66FA","\u670E","\uF929","\u6766","\u67BB",
"\u6852","\u67C0","\u6801","\u6844","\u68CF","\uFA13","\u6968","\uFA14","\u6998","\u69E2",
"\u6A30","\u6A6B","\u6A46","\u6A73","\u6A7E","\u6AE2","\u6AE4","\u6BD6","\u6C3F","\u6C5C",
"\u6C86","\u6C6F","\u6CDA","\u6D04","\u6D87","\u6D6F","\u6D96","\u6DAC","\u6DCF","\u6DF8",
"\u6DF2","\u6DFC","\u6E39","\u6E5C","\u6E27","\u6E3C","\u6EBF","\u6F88","\u6FB5","\u6FF5",
"\u7005","\u7007","\u7028","\u7085","\u70AB","\u710F","\u7104","\u715C","\u7146","\u7147",
"\uFA15","\u71C1","\u71FE","\u72B1",

"\u72BE","\u7324","\uFA16","\u7377","\u73BD","\u73C9","\u73D6","\u73E3","\u73D2","\u7407",
"\u73F5","\u7426","\u742A","\u7429","\u742E","\u7462","\u7489","\u749F","\u7501","\u756F",
"\u7682","\u769C","\u769E","\u769B","\u76A6","\uFA17","\u7746","\u52AF","\u7821","\u784E",
"\u7864","\u787A","\u7930","\uFA18","\uFA19","\uFA1A","\u7994","\uFA1B","\u799B","\u7AD1",
"\u7AE7","\uFA1C","\u7AEB","\u7B9E","\uFA1D","\u7D48","\u7D5C","\u7DB7","\u7DA0","\u7DD6",
"\u7E52","\u7F47","\u7FA1","\uFA1E","\u8301","\u8362","\u837F","\u83C7","\u83F6","\u8448",
"\u84B4","\u8553","\u8559","\u856B","\uFA1F","\u85B0","\uFA20","\uFA21","\u8807","\u88F5",
"\u8A12","\u8A37","\u8A79","\u8AA7","\u8ABE","\u8ADF","\uFA22","\u8AF6","\u8B53","\u8B7F",
"\u8CF0","\u8CF4","\u8D12","\u8D76","\uFA23","\u8ECF","\uFA24","\uFA25","\u9067","\u90DE",
"\uFA26","\u9115","\u9127","\u91DA",

"\u91D7","\u91DE","\u91ED","\u91EE","\u91E4","\u91E5","\u9206","\u9210","\u920A","\u923A",
"\u9240","\u923C","\u924E","\u9259","\u9251","\u9239","\u9267","\u92A7","\u9277","\u9278",
"\u92E7","\u92D7","\u92D9","\u92D0","\uFA27","\u92D5","\u92E0","\u92D3","\u9325","\u9321",
"\u92FB","\uFA28","\u931E","\u92FF","\u931D","\u9302","\u9370","\u9357","\u93A4","\u93C6",
"\u93DE","\u93F8","\u9431","\u9445","\u9448","\u9592","\uF9DC","\uFA29","\u969D","\u96AF",
"\u9733","\u973B","\u9743","\u974D","\u974F","\u9751","\u9755","\u9857","\u9865","\uFA2A",
"\uFA2B","\u9927","\uFA2C","\u999E","\u9A4E","\u9AD9","\u9ADC","\u9B75","\u9B72","\u9B8F",
"\u9BB1","\u9BBB","\u9C00","\u9D70","\u9D6B","\uFA2D","\u9E19","\u9ED1","\u2170","\u2171",
"\u2172","\u2173","\u2174","\u2175","\u2176","\u2177","\u2178","\u2179","\uFFE2","\uFFE4",
"\uFF07","\uFF02"
);


var moji = moji1 + moji2 + moji3 + moji4 + moji5 + block.join("");


function checkmoji(str){
    re = new RegExp("[" + moji + "]", "g");
    ret = str.match(re);
    if(ret == null){ ret = ""; }
    else{ ret = ret.join(""); }
    
    return ret;
}

//  数値チェック  
function checkNum(str){
	okstr = '-0123456789';
	err = 0;
	for (i=0;i<str.length;i++){
		if (okstr.indexOf(str.charAt(i)) == -1) err++;
	}

	if(str.length == 1){		// 一文字だけの場合
		if(str.indexOf('-') != -1) err++;	//「-」だったエラー
	}else if(str.length > 1){		// 複数文字の場合
		if(str.indexOf('-',1) != -1) err++;	//最初の文字以外が「-」だったエラー
	}
	if (err!=0){
		return false;
	}else{
		return true;
	}

}

//---------------------
// 半角英数チェック  
//---------------------
function isStrHan(str){
	var iCount;
	var iCode;
	var ret_flg;

	ret_flg = true;

	st_val=str;
	for (iCount=0 ; iCount<st_val.length ; iCount++){
    	iCode = st_val.charCodeAt(iCount);
		if ((45 <= iCode && iCode <= 58) || (63 <= iCode && iCode <= 90) ||
			(97 <= iCode && iCode <= 122) || iCode == 95 || iCode == 38 || iCode == 126 || iCode == 0x20) {
		}else{
			ret_flg = false;
		}
    }

	return ret_flg;
}

//---------------------
// メールアドレスチェック  
//---------------------
function checkMail(value){
    check = /.+@.+\..+/;
    if (!value.match(check)) {
        return false;
	}
    return true;
}

$(document).ready(function(){
	/* ---------------------------- */
	/* 簡易検索テキストボックスの初期値制御 */
	/* ---------------------------- */
		var dColor = '#999999';	//初期値の文字色
		var fColor = '#000000';	//通常入力時の文字色
		var dValue = 'キーワードを入力してください';

		if($('#q').length > 0){
			//初期値
			if($('#q').val() == "" || $('#q').val() == dValue){
				$('#q').val(dValue);
				$('#q').css('color',dColor);
			}

			//選択されたときの処理
			$('#q').focus(function(){
				if($(this).val() == dValue){
					$(this).val('');
					$(this).css('color', fColor);
				}
			})
			//選択が外れたときの処理
			.blur(function(){
				if($(this).val() == dValue || $(this).val() == ''){
					$(this).val(dValue);
					$(this).css('color',dColor);
				};
			});
		}
});


//---------------------
// ピヨ消し
//---------------------
function hidePiyo(){
//    $('#piyo').hide();
	$('#jama_piyo_area').animate({
		'left': '-500px'
	});
	$('#jama_piyo_area2').animate({
		'left': '-500px'
	});
    return false;

}
function hidePiyoNew(){
//    $('#piyo').hide();
	$('.new_piyo_area').animate({
		'left': '-2000px'
	});
	$('.new_piyo_area2').animate({
		'left': '-2000px'
	});
    return false;

}
