$(document).ready(function(){
	var disp_detail_p1 = $.cookie("hidden_detail_p1");
	if(disp_detail_p1 == 1){
		//非表示
		$("#detail_h3_1").html('<a href="javascript:show_p01();"><img src="/img/icon_plus.png">&nbsp;' + $("#detail_h3_hidden1").val() + '</a>');
		$("#detail_p01").hide();
		$("#wa3piyo_line02").html('<img src="/img/wa3piyo_line01.png" title="image piyo" alt="image piyo">');
	}else{
		//表示
		$("#detail_h3_1").html('<a href="javascript:hide_p01();"><img src="/img/icon_minus.png">&nbsp;' + $("#detail_h3_hidden1").val() + '</a>');
		$("#detail_p01").show();
		$("#wa3piyo_line02").html('<img src="/img/wa3piyo_line02.png" title="image piyo" alt="image piyo">');
	}

	var disp_detail_p2 = $.cookie("hidden_detail_p2");
	if(disp_detail_p2 == 1){
		//非表示
		$("#detail_h3_2").html('<a href="javascript:show_p02();"><img src="/img/icon_plus.png">&nbsp;' + $("#detail_h3_hidden2").val() + '</a>');
		$("#detail_p02").hide();
		$("#wa3piyo_line03").html('<img src="/img/wa3piyo_line01.png" title="image piyo2" alt="image piyo2">');
	}else{
		//表示
		$("#detail_h3_2").html('<a href="javascript:hide_p02();"><img src="/img/icon_minus.png">&nbsp;' + $("#detail_h3_hidden2").val() + '</a>');
		$("#detail_p02").show();
		$("#wa3piyo_line03").html('<img src="/img/wa3piyo_line03.png" title="image piyo2" alt="image piyo2">');
	}

	var disp_detail_p3 = $.cookie("hidden_detail_p3");
	if(disp_detail_p3 == 1){
		//非表示
		$("#detail_h3_3").html('<a href="javascript:show_p03();"><img src="/img/icon_plus.png">&nbsp;' + $("#detail_h3_hidden3").val() + '</a>');
		$("#detail_p03").hide();
		$("#wa3piyo_line04").html('<img src="/img/wa3piyo_line01.png" title="一番上に戻るよ" alt="一番上に戻るよ">');
	}else{
		//表示
		$("#detail_h3_3").html('<a href="javascript:hide_p03();"><img src="/img/icon_minus.png">&nbsp;' + $("#detail_h3_hidden3").val() + '</a>');
		$("#detail_p03").show();
		$("#wa3piyo_line04").html('<img src="/img/wa3piyo_line04.png" title="一番上に戻るよ" alt="一番上に戻るよ">');
	}

	var disp_detail_p4 = $.cookie("hidden_detail_p4");
	if(disp_detail_p4 == 1){
		//非表示
		$("#detail_h3_4").html('<a href="javascript:show_p04();"><img src="/img/icon_plus.png">&nbsp;' + $("#detail_h3_hidden4").val() + '</a>');
		$("#newlist_sub_area").hide();
	}else{
		//表示
		$("#detail_h3_4").html('<a href="javascript:hide_p04();"><img src="/img/icon_minus.png">&nbsp;' + $("#detail_h3_hidden4").val() + '</a>');
		$("#newlist_sub_area").show();
	}

	var disp_detail_p5 = $.cookie("hidden_detail_p5");
	if(disp_detail_p5 == 1){
		//非表示
		$("#detail_h3_5").html('<a href="javascript:show_p05();"><img src="/img/icon_plus.png">&nbsp;' + $("#detail_h3_hidden5").val() + '</a>');
		$("#disp_history_sub_area").hide();
	}else{
		//表示
		$("#detail_h3_5").html('<a href="javascript:hide_p05();"><img src="/img/icon_minus.png">&nbsp;' + $("#detail_h3_hidden5").val() + '</a>');
		$("#disp_history_sub_area").show();
	}

	var disp_detail_p6 = $.cookie("hidden_detail_p6");
	if(disp_detail_p6 == 1){
		//非表示
		$("#detail_h3_6").html('<a href="javascript:show_p06();"><img src="/img/icon_plus.png">&nbsp;' + $("#detail_h3_hidden6").val() + '</a>');
		$("#initial_area").hide();
	}else{
		//表示
		$("#detail_h3_6").html('<a href="javascript:hide_p06();"><img src="/img/icon_minus.png">&nbsp;' + $("#detail_h3_hidden6").val() + '</a>');
		$("#initial_area").show();
	}

	var disp_detail_p7 = $.cookie("hidden_detail_p7");
	if(disp_detail_p7 == 1){
		//非表示
		$("#detail_h3_7").html('<a href="javascript:show_p07();"><img src="/img/icon_plus.png">&nbsp;' + $("#detail_h3_hidden7").val() + '</a>');
		$("#etc_area").hide();
	}else{
		//表示
		$("#detail_h3_7").html('<a href="javascript:hide_p07();"><img src="/img/icon_minus.png">&nbsp;' + $("#detail_h3_hidden7").val() + '</a>');
		$("#etc_area").show();
	}
});

function show_p01(){
	//表示
	$("#detail_p01").slideDown(300);
	$("#detail_h3_1").html('<a href="javascript:hide_p01();"><img src="/img/icon_minus.png">&nbsp;' + $("#detail_h3_hidden1").val() + '</a>');
	$("#wa3piyo_line02").html('<img src="/img/wa3piyo_line02.png" title="image piyo" alt="image piyo">');
	$.cookie("hidden_detail_p1", "0", { expires: 30 });
}

function hide_p01(){
	//非表示
	$("#detail_p01").slideUp(300);
	$("#detail_h3_1").html('<a href="javascript:show_p01();"><img src="/img/icon_plus.png">&nbsp;' + $("#detail_h3_hidden1").val() + '</a>');
	$("#wa3piyo_line02").html('<img src="/img/wa3piyo_line01.png" title="image piyo" alt="image piyo">');
	$.cookie("hidden_detail_p1", "1", { expires: 30 });
}

function show_p02(){
	//表示
	$("#detail_p02").slideDown(300);
	$("#detail_h3_2").html('<a href="javascript:hide_p02();"><img src="/img/icon_minus.png">&nbsp;' + $("#detail_h3_hidden2").val() + '</a>');
	$("#wa3piyo_line03").html('<img src="/img/wa3piyo_line03.png" title="image piyo2" alt="image piyo2">');
	$.cookie("hidden_detail_p2", "0", { expires: 30 });
}

function hide_p02(){
	//非表示
	$("#detail_p02").slideUp(300);
	$("#detail_h3_2").html('<a href="javascript:show_p02();"><img src="/img/icon_plus.png">&nbsp;' + $("#detail_h3_hidden2").val() + '</a>');
	$("#wa3piyo_line03").html('<img src="/img/wa3piyo_line01.png" title="image piyo2" alt="image piyo2">');
	$.cookie("hidden_detail_p2", "1", { expires: 30 });
}

function show_p03(){
	//表示
	$("#detail_p03").slideDown(300);
	$("#detail_h3_3").html('<a href="javascript:hide_p03();"><img src="/img/icon_minus.png">&nbsp;' + $("#detail_h3_hidden3").val() + '</a>');
	$.cookie("hidden_detail_p3", "0", { expires: 30 });
	$("#wa3piyo_line04").html('<img src="/img/wa3piyo_line04.png" title="一番上に戻るよ" alt="一番上に戻るよ">');
}

function hide_p03(){
	//非表示
	$("#detail_p03").slideUp(300);
	$("#detail_h3_3").html('<a href="javascript:show_p03();"><img src="/img/icon_plus.png">&nbsp;' + $("#detail_h3_hidden3").val() + '</a>');
	$.cookie("hidden_detail_p3", "1", { expires: 30 });
	$("#wa3piyo_line04").html('<img src="/img/wa3piyo_line01.png" title="一番上に戻るよ" alt="一番上に戻るよ">');
}

function show_p04(){
	//表示
	$("#newlist_sub_area").slideDown(300);
	$("#detail_h3_4").html('<a href="javascript:hide_p04();"><img src="/img/icon_minus.png">&nbsp;' + $("#detail_h3_hidden4").val() + '</a>');
	$.cookie("hidden_detail_p4", "0", { expires: 30 });
}

function hide_p04(){
	//非表示
	$("#newlist_sub_area").slideUp(300);
	$("#detail_h3_4").html('<a href="javascript:show_p04();"><img src="/img/icon_plus.png">&nbsp;' + $("#detail_h3_hidden4").val() + '</a>');
	$.cookie("hidden_detail_p4", "1", { expires: 30 });
}

function show_p05(){
	//表示
	$("#disp_history_sub_area").slideDown(300);
	$("#detail_h3_5").html('<a href="javascript:hide_p05();"><img src="/img/icon_minus.png">&nbsp;' + $("#detail_h3_hidden5").val() + '</a>');
	$.cookie("hidden_detail_p5", "0", { expires: 30 });
}

function hide_p05(){
	//非表示
	$("#disp_history_sub_area").slideUp(300);
	$("#detail_h3_5").html('<a href="javascript:show_p05();"><img src="/img/icon_plus.png">&nbsp;' + $("#detail_h3_hidden5").val() + '</a>');
	$.cookie("hidden_detail_p5", "1", { expires: 30 });
}

function show_p06(){
	//表示
	$("#initial_area").slideDown(300);
	$("#detail_h3_6").html('<a href="javascript:hide_p06();"><img src="/img/icon_minus.png">&nbsp;' + $("#detail_h3_hidden6").val() + '</a>');
	$.cookie("hidden_detail_p6", "0", { expires: 30 });
}

function hide_p06(){
	//非表示
	$("#initial_area").slideUp(300);
	$("#detail_h3_6").html('<a href="javascript:show_p06();"><img src="/img/icon_plus.png">&nbsp;' + $("#detail_h3_hidden6").val() + '</a>');
	$.cookie("hidden_detail_p6", "1", { expires: 30 });
}

function show_p07(){
	//表示
	$("#etc_area").slideDown(300);
	$("#detail_h3_7").html('<a href="javascript:hide_p07();"><img src="/img/icon_minus.png">&nbsp;' + $("#detail_h3_hidden7").val() + '</a>');
	$.cookie("hidden_detail_p7", "0", { expires: 30 });
}

function hide_p07(){
	//非表示
	$("#etc_area").slideUp(300);
	$("#detail_h3_7").html('<a href="javascript:show_p07();"><img src="/img/icon_plus.png">&nbsp;' + $("#detail_h3_hidden7").val() + '</a>');
	$.cookie("hidden_detail_p7", "1", { expires: 30 });
}

//トップに戻る
function moveTop(){
	$('html,body').animate({scrollTop: 0, scrollLeft: 0}, 200);
}