hljs.registerLanguage('terminal', function(hljs) {
  return({
    aliases: ['term'],
    k: {
      keyword: ''
    },
    c: [
    {
      cN: 'prompt',
      b: /^\$/,
      e: /.|$/
    },
    {
      cN: 'comment',
      b: /^#.*$/
    }]
  });
});

hljs.configure({tabReplace: '  '}); // 2 spaces
hljs.initHighlightingOnLoad();

$("table").addClass("table table-striped");
